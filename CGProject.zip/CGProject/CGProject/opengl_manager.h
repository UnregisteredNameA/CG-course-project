#pragma once
#include "glew.h"
#include "glut.h"
#include <functional>

#define DEFAULT_FUNCTION NULL

#define INITIAL_WIDTH 960
#define INITIAL_HEIGHT 640
#define EXTRA_HEIGHT 0

class OpenGLManager
{
public:
	static int width, height;

	OpenGLManager(int argc, char *argv[]);

	static void setSceneViewport();
	static void setStaticViews();

	static void setGlutDisplayFunc(void(*f)());
	static void setGlutReshapeFunc (void(*f)(int, int));
	static void setGlutIdleFunc(void(*f)());
	static void startGlutMainLoop();
	static void setGlutTimerFunc(void(*f)(int), int);
	static void otherInits();

	static void setGlutKeyboardFunc(void(*f)(unsigned char key, int x, int y));
	static void setGlutMouseFunc(void(*f)(int button, int state, int x, int y));
	~OpenGLManager();
};

