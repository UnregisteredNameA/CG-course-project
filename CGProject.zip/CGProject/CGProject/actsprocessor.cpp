#include "pch.h"
#include "actsprocessor.h"


extern bool drawing_mutex_acquired;

Interpreter event_interpreter;


void anim_event_process(int interval)
{
	do
	{
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		if (!drawing_mutex_acquired)
			lck.lock();
		unique_lock<recursive_mutex> lckanim(acts.lock, defer_lock);
		lckanim.lock();

		if (elements.new_duplicated_name_object)
		{
			for (auto it = acts.animations.begin(); it != acts.animations.end(); ++it)
			{
				Animation &anim = **it;
				if (anim.multi)
				{
					anim.multi_relevant_object.clear();
					elements.multi_findShapeByName(anim.multi_rev_objname, anim.multi_relevant_object);
				}
			}
			for (auto it = acts.events.begin(); it != acts.events.end(); ++it)
			{
				Event &ent = **it;
				if (ent.multi)
				{
					ent.multi_relevant_object.clear();
					elements.multi_findShapeByName(ent.multi_rev_objname, ent.multi_relevant_object);
				}
			}
			elements.new_duplicated_name_object = 0;
		}

		for (auto it = acts.events.begin(); it != acts.events.end(); ++it)
		{
			Event &ent = **it;

			if (ent.remaining_trigger_times == 0) continue;
			if (ent.remaining_active_delay > 0)
			{
				ent.remaining_active_delay -= interval;
				continue;
			}

			if (ent.remaining_trigger_interval > 0)
			{
				ent.remaining_trigger_interval -= interval;
				continue;
			}

			if (!ent.multi)
			{
				if (ent.triggerOn->operator()(ent.relevant_object))
				{
					elements.set_this(ent.relevant_object);
					//context.current_condition_default = ent.relevant_object;
					for (auto it = ent.statements.begin(); it != ent.statements.end(); ++it)
					{
						event_interpreter.interpret(*it);
					}
					ent.remaining_trigger_interval += ent.trigger_interval;
					if (ent.remaining_trigger_times != EVERLASTING)
						ent.remaining_trigger_times -= 1;
				}
			}
			else
			{
				for (Shape* revobj : ent.multi_relevant_object)
				{
					//context.current_condition_default = revobj;
					if (ent.triggerOn->operator()(revobj))
					{
						elements.set_this(revobj);
						for (auto it = ent.statements.begin(); it != ent.statements.end(); ++it)
						{
							event_interpreter.interpret(*it);
						}
						ent.remaining_trigger_interval += ent.trigger_interval;
						if(ent.remaining_trigger_times != EVERLASTING)
							ent.remaining_trigger_times -= 1;
					}
				}
			}
		}

		for (auto it = acts.animations.begin(); it != acts.animations.end(); ++it)
		{
			Animation &anim = **it;

			if (anim.conditions.startOn == nullptr || anim.started == 1 || anim.conditions.startOn->operator()(anim.relevant_object))
				anim.started = 1;

			if (anim.started && anim.conditions.stopOn != nullptr && anim.conditions.stopOn->operator()(anim.relevant_object))
			{
				anim.started = 0;
				anim.remaining_expire_time = anim.expire_time;
				anim.remaining_trigger_interval = anim.trigger_interval;
				anim.remaining_delay_time = anim.delay_time;
			}

			if (!anim.started) continue;

			if (anim.remaining_delay_time <= 0)
			{
				if (anim.expire_time != EVERLASTING)
					anim.remaining_expire_time -= interval;
				anim.remaining_trigger_interval -= interval;
			}
			else
				anim.remaining_delay_time -= interval;

			if (anim.remaining_expire_time <= 0) continue;

			if (anim.remaining_trigger_interval <= 0)
			{
				for (auto p = anim.objedits.begin(); p != anim.objedits.end(); ++p)
				{
					if(!anim.multi)
						(**p)(anim.relevant_object);
					else
					{
						for (Shape* x : anim.multi_relevant_object)
							(**p)(x);
					}
				}
				anim.remaining_trigger_interval += anim.trigger_interval;
			}
		}

		

	} while (false);
	glutTimerFunc(10, anim_event_process, ANIMATION_PROCESS_INTERVAL);
}




Interpreter keyboard_interpreter;

void keyboard(unsigned char key, int x, int y)
{
	vector<string>::iterator it;
	if (keymap.debug) std::cout << "[key : " << (int)key << "]\n";
	if (!keymap.custom)
	{
		switch (key)
		{
		case 'a':
			elements.ob.eye[0] -= 0.2;
			elements.ob.center[0] -= 0.2;
			break;
		case 'd':
			elements.ob.eye[0] += 0.2;
			elements.ob.center[0] += 0.2;
			break;
		case 'w':
			elements.ob.eye[1] += 0.2;
			elements.ob.center[1] += 0.2;
			break;
		case 's':
			elements.ob.eye[1] -= 0.2;
			elements.ob.center[1] -= 0.2;
			break;
		case 'z':
			elements.ob.eye[2] += 0.2;
			elements.ob.center[2] += 0.2;
			break;
		case 'c':
			elements.ob.eye[2] -= 0.2;
			elements.ob.center[2] -= 0.2;
			break;
		}
	}
	else
	{
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		if (!drawing_mutex_acquired)
			lck.lock();
		for (it = keymap.forkey(key).begin(); it != keymap.forkey(key).end(); ++it)
		{
			keyboard_interpreter.interpret(*it);
		}
	}
}
