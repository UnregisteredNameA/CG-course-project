#pragma once
#include <functional>
#include "glew.h"
#include "glut.h"
#include <vector>
#include <stdexcept>
#include <initializer_list>
#include <list>
#include <map>
#include <thread>
#include <mutex>
#include <set>
#include <Windows.h>
#include <stack>
#include <sstream>
#include "glm/glm.hpp"
#include "glm/ext/matrix_transform.hpp"
#include <iostream>
#include <fstream>
using namespace std;

#define SHAPE_SLICE 90
#define SHAPE_STACK 90
#define ANIMATION_PROCESS_INTERVAL 10
#define EVERLASTING 2147483647


class GlobalSettings {
public:
	static bool light_enabled;
	static int background[4];
	static float perspective_far;
	static string background_texture;
	static string cover_texture;
	static string to_string()
	{
		string ret;
		if (background_texture.size())
			ret += "global background image " + background_texture + " ;\n";
		if (cover_texture.size())
			ret += "global cover image " + cover_texture + " ;\n";
		if (perspective_far != 100)
			ret += "global far " + ::to_string(perspective_far) + " ;\n";
		return ret;
	}
};

struct _Opt {
	float r, g, b, a;
	int valid = 0;
	_Opt &operator=(std::initializer_list<float> args);
	void factorof(float f)
	{
		r *= f; g *= f; b *= f; a *= f;
	}
};

void myCube(float a);

struct Point3d { 
	Point3d() : x(0), y(0), z(0) {}
	Point3d(float xx, float yy, float zz) : x(xx), y(yy), z(zz) {}
	float x, y, z; 
};
Point3d cross_product(float x1, float y1, float z1, float x2, float y2, float z2);
Point3d normalize(Point3d vec);
void myRevolutionSurface(int rotp, int layerp, float *x, float *y, int triangle, float requested_degree_per_texture = -1);
Point3d operator+(const Point3d &a, const Point3d &b);
Point3d operator-(const Point3d &a, const Point3d &b);

class Material {
public:
	string name;
	_Opt ambient, specular, diffuse, emission;
	float shininess; 
	int shininess_valid = 0;

	static void set_default_material();
	void operator()();

	static void set_color_while_light_enabled(float r, float g, float b, float a);

	string to_string();

};


#define BITMAP_ID 0x4D42
#define MAX_TEXTURE_NUM 25
class Texture {
private:
	unsigned char *LoadBitmapFile(const char *filename, BITMAPINFOHEADER *bitmapInfoHeader);
	unsigned char *LoadBitmapFile_whiteToAlpha(const char *filename, BITMAPINFOHEADER *bitmapInfoHeader);
	void texload(const char *filename, int texture);
	void texload_alpha(const char *filename, int texture);
	
	static int alloc_i;
	static unsigned int allocatedID[MAX_TEXTURE_NUM];

public:
	static void texture_init();
	string name;
	string filename;
	unsigned int texture_id;
	int load_texture(const string &fname);
	int load_texture_alpha(const string &fname);

	void operator()() { glBindTexture(GL_TEXTURE_2D, texture_id); }
	
	static void set_no_texture() { glBindTexture(GL_TEXTURE_2D, 0); }

	string to_string() { return string("texture ") + name + ' ' + filename + ";\n\n"; }
};


class ShapeEditor;


class Shape
{
	friend class Condition;
private:
	static int shape_count;
protected:
	bool shoulddelete = 0;
private:
	int int_id;
	std::function<void()> completeFunc;

	int state;

	bool translate;
	float translatex, translatey, translatez;

	bool rotate;
	float rotatedeg, rotatex, rotatey, rotatez;

	bool scale;
	float scalex, scaley, scalez;

	bool color;
	float red, green, blue, alpha;

	bool self_rotate;
	float selfrotatedeg, selfrotatex, selfrotatey, selfrotatez;

	std::function<void()> preprocess;

	int textureid;
	string texturename;
	std::function<void()> textureFunc;

	bool material;
	string materialname;
	std::function<void()> materialFunc;
	vector<string> materialTraits;
	std::vector<std::function<void()>> materialFuncVec;

	vector<Shape*> coord_track_stack;

	ShapeEditor *specific_trigger;

public:
	static void init();

	string name;

	int hide = 0;

	Shape() : textureid(0),
			preprocess(nullptr), textureFunc(nullptr), materialFunc(nullptr), completeFunc(nullptr),
			translatex(0), translatey(0), translatez(0), scalex(1), scaley(1), scalez(1),
			red(1), green(1), blue(1), alpha(1), self_rotate(0),
		translate(0), rotate(0), scale(0), color(1), material(0) { ++shape_count; int_id = shape_count; };
	~Shape() {};

	void set_translate(float x, float y, float z);
	void set_delta_translate(float x, float y, float z);
	void set_rotate(float deg, float x, float y, float z);
	void set_delta_rotate(float deg);
	void set_self_rotate(float deg, float x, float y, float z);
	void set_delta_self_rotate(float deg);
	void set_scale(float x, float y, float z);
	void set_delta_scale(float x, float y, float z);
	void set_multiple_scale(float x, float y, float z);
	void set_color(float r, float g, float b, float a);

	void set_state(int state);
	void set_delta_state(int delta);
	int get_state();

	void replace_entire_func(std::function<void()> f);
	void replace_preprocess_func(std::function<void()> f);
	void replace_texture_func(std::function<void()> f);
	void set_texture_name(const string &name);
	void set_texture_id(int x);
	void set_material_name(const string &name);
	void replace_material_func(std::function<void()> f);
	void add_material_func(std::function<void()> f);
	void add_material_trait(const string &str);

	void copy_track_stack_of(Shape *which);
	void clear_track_stack();
	void add_to_stack(Shape *which);
	void rotate_translate_scale();

	void coord_push_previous_matrixes();
	void coord_pop_previous_matrixes();

	void coord_originate_from_this_object();
	void coord_reset();

	virtual void specific_draw() = 0;
	virtual string specific_to_string() = 0;
	virtual float collide_radius() = 0;
	virtual void set_attribute(std::initializer_list<float>) {};
	virtual void set_attribute(float *) {};

	Point3d absolute_coordinate();
protected:
	void set_attribute_delete(float *p) { set_attribute(p); delete[] p; }


public:
	void draw();
	int get_int_id() { return int_id; }
	void to_string(string &buf);
};

class Cube : public Shape {
private:
	float a = 1;
public:
	void specific_draw();
	virtual string specific_to_string();
	void set_attribute(std::initializer_list<float>);
	void set_attribute(float *);
	float collide_radius();
};

class Cuboid : public Shape {
private:
	float xa = 1, ya = 1, za = 1;
public:
	void specific_draw();
	virtual string specific_to_string();
	void set_attribute(std::initializer_list<float>);
	void set_attribute(float *) ;
	float collide_radius();
};

class Sphere : public Shape {
	friend class Shape;
private:
	static GLuint listno;
	float r = 1;
public:
	void specific_draw();
	virtual string specific_to_string();
	void set_attribute(std::initializer_list<float>);
	void set_attribute(float *);
	float collide_radius();
};

class Cone : public Shape {
private:
	float b = 1, h = 1;
public:
	void specific_draw();
	virtual string specific_to_string();
	void set_attribute(std::initializer_list<float>);
	void set_attribute(float *);
	float collide_radius();
};

class Cylinder : public Shape {
private:
	float rbtm = 1, rtop = 1, h = 1;
	GLUquadricObj *obj;
public:
	void specific_draw();
	virtual string specific_to_string();
	void set_attribute(std::initializer_list<float>);
	void set_attribute(float *);
	float collide_radius();

};

class NullObject : public Shape{
public:
	virtual string specific_to_string();
	void specific_draw();
	float collide_radius();
};

class Prism : public Shape {
private:
	float n = 4, rbtm = 1, rtop = 1, h = 1;
public:
	void specific_draw();
	virtual string specific_to_string();
	void set_attribute(std::initializer_list<float>);
	void set_attribute(float *);
	float collide_radius();
};

class Pyramid : public Shape {
private:
	float n = 4, r = 1, h = 1;
public:
	void specific_draw();
	virtual string specific_to_string();
	void set_attribute(std::initializer_list<float>);
	void set_attribute(float *);
	float collide_radius();
};

class ObjFile : public Shape {
private:
	int type;  //��ǵ�ǰObj�ļ�����
	//type==1����򵥵�obj���ͣ�ֻ����v��f
	//type==2������vn,vt,��f�ĸ�ʽΪ����v//n
	//type==3������vn,vt,��f�ĸ�ʽΪ��������v//n���޷�����
	string filename;
	vector<vector<GLfloat>>vSets;//��Ŷ���(x,y,z)����
	vector<vector<GLint>>fSets;//������������������
	vector<glm::vec3>vertices;
	vector<glm::vec3>normals;
	bool load_type2(const string &fn);
public:
	bool load_file(const string &fn);
	void specific_draw();
	string specific_to_string();
	float collide_radius();

};




class Light {
private:
	static int light_cnt;
	int glLightNo;
public:
	Light();

	int id;
	float x, y, z;
	_Opt ambient, specular, diffuse;

	Shape *trackon;

	int on = 1;
	bool edited = 1;
	void set_pos(std::initializer_list<float>);
	void set_lighting();
	string to_string();
};

namespace OB_ACTION {
	constexpr int DEFAULT = 0;
	constexpr int TRACK = 1;
	constexpr int STARE_AT = 2;
	constexpr int FIX_TO = 3;
}

class Observer 
{
private:
	int action = 0;
	Shape *relevant_obj = nullptr;
	Point3d old_center, old_objpos;
	Point3d relevant_pos_vec;
	
	int look_method = 666;

public:
	static const int BASED_ON_VISION = 123;
	static const int BASED_ON_CENTER = 666;
	Observer();
	Observer(double ex, double ey, double ez, double cx, double cy, double cz, double ux, double uy, double uz);
	double eye[3];
	double center[3];
	double up[3];
	double visionvec[3];
	void set_look_method(int method);
	void set_eye_position(float x, float y, float z);
	void set_eye_delta_position(float dx, float dy, float dz);
	void set_center_position(float x, float y, float z);
	void set_center_delta_position(float dx, float dy, float dz);
	void set_vision_vector(float x, float y, float z);
	void set_vision_delta_vector(float dx, float dy, float dz);

	void track(const string &objname); //BASED ON CENTER
	void stare_at(const string &objname); //BASED ON CENTER
	void fix_to(const string &objname, float dx, float dy, float dz); //BASED ON VISION VECTOR
	void reset_default();
	Point3d get_sight_vector();
	

	void glObserverLook();
};


inline bool valid_float_number(const string &s);

class Condition;

class ShapeEditor {
private:
	Condition *cond = nullptr;
public:
	string condition_str;
	string cmd, cmdi;
	vector<float> args;
	ShapeEditor() {};
	static int expected_argnum(const string &cmd);

	ShapeEditor(const string &str);

	virtual void operator()(Shape *p);

};

class LightEditor {
public:
	string cmd, cmdi;
	vector<float> args;
	static int expected_argnum(const string &cmd);
	void operator()(Light *p);
};


class RegisteredElements {
	friend class SceneSaver;
private:
	set<Shape*> shapes;
	list<Light*> lights;
	vector<Material*> materials;
	vector<Texture*> textures;

	map<string, Shape*> shapeRec;

	set<Shape*>::iterator focus;

	Shape *_this;

public:
	recursive_mutex lock;

	Observer ob;
	
	int new_duplicated_name_object = 0;

	RegisteredElements() : ob(0, 0, 8, 0, 0, 0, 0, 1, 0) {}
	void set_this(Shape *th)
	{
		_this = th;
	}
	Shape *findShapeByName(const string &sname)
	{
		if (sname == "_this") return _this;
		if (sname == "focus" && shapes.size())
			return *focus;
		auto x = shapeRec.find(sname);
		if (x != shapeRec.end())
			return x->second;
		else
			return nullptr;
	}
	void multi_findShapeByName(const string &sname, vector<Shape*> &res)
	{
		for (auto it = shapes.begin(); it != shapes.end(); ++it)
		{
			if((*it)->name == sname) res.push_back(*it);
		}
	}
	Light *findLightByID(int id)
	{
		for (auto x : lights) if (x->id == id) return x;
		return nullptr;
	}
	Material *findMaterialByName(const string &mname)
	{
		for (auto x : materials) if (x->name == mname) return x;
		return nullptr;
	}
	Texture *findTextureByName(const string &tname)
	{
		for (auto x : textures) if (x->name == tname) return x;
		return nullptr;
	}


	void add_shape(Shape *p) 
	{ 
		shapes.insert(p); 
		if (p->name[0] == '@') new_duplicated_name_object = 3;
		if (shapes.size() == 1) focus = shapes.begin(); 
		shapeRec[p->name] = p; 
	}
	void add_light(Light *p) { lights.push_back(p); }
	void add_material(Material *p) { materials.push_back(p); }
	void add_texture(Texture *p) { textures.push_back(p); }

	void focus_next() { ++focus; if (focus == shapes.end()) focus = shapes.begin(); }
	void focus_prev() { if (focus == shapes.begin()) focus = shapes.end(); --focus; }
	void set_focus(const string &name) 
	{
		set<Shape*>::iterator tmp = shapes.find(findShapeByName(name));
		if (tmp != shapes.end()) focus = tmp;
	}

	void remove_shape(const string &name) { shapes.erase(findShapeByName(name)); }
	void remove_light(int Lid) { lights.remove(findLightByID(Lid)); }
	void remove_shape_by_ptr(Shape *p) { if (p->name[0] == '@') new_duplicated_name_object = 1; shapes.erase(p); }

	void render_lights() 
	{
		for (auto it = lights.begin(); it != lights.end(); ++it) (*it)->set_lighting();
	}
	void render_shapes()
	{
		for (auto it = shapes.begin(); it != shapes.end(); ++it) (*it)->draw();
	}
	
	
};

extern RegisteredElements elements;




class Condition {
private:
	vector<string> subconds;
public:
	Condition(const string &condstring);
	string cond;
	bool operator()(Shape *p);

};



class Animation {
	friend void anim_event_process(int);
public:
	int multi = 0;
	string name;
	string multi_rev_objname;
	Animation(const string &aname, string objname, int lastingTime, int triggerInterval, int delay)
		: name(aname), expire_time(lastingTime), trigger_interval(triggerInterval), delay_time(delay),
		remaining_trigger_interval(triggerInterval), remaining_expire_time(lastingTime) {
		if (objname[0] != '@')
			relevant_object = elements.findShapeByName(objname);
		else
		{
			multi = 1;
			multi_rev_objname = objname;
			elements.multi_findShapeByName(objname, multi_relevant_object);
		}
	}

	void add_object_edits(ShapeEditor *p)
	{
		this->objedits.push_back(p);
	};
	virtual ~Animation() {}
	struct _Conditions {
		Condition *startOn = nullptr;
		Condition *stopOn = nullptr;
		//Condition *playWhile = nullptr;
		//Condition *pauseWhile = nullptr;
	} conditions;

private:
	Shape *relevant_object;
	vector<Shape*> multi_relevant_object;
	vector<ShapeEditor*> objedits;
	int delay_time;
	int expire_time;
	int trigger_interval;
	int remaining_expire_time;
	int remaining_delay_time;
	int remaining_trigger_interval;
	
	int started = 0;
};


class Event {
	
	friend void anim_event_process(int);
	friend void dbg();
private:
	int activate_delay, remaining_active_delay,
		total_trigger_times, remaining_trigger_times,
		trigger_interval, remaining_trigger_interval;
	Shape *relevant_object;
	string multi_rev_objname;
	vector<Shape*> multi_relevant_object;
	vector<string> statements;
	bool triggered = 0;

public:
	int multi = 0;
	Event() : activate_delay(0), remaining_active_delay(0) {}
	Event(int delay) : activate_delay(delay), remaining_active_delay(delay) {}
	string name;
	Condition *triggerOn = nullptr;
	void add_statements(const string &s)
	{
		this->statements.push_back(s);
	};
	void set_trigger_object(const string &objname)
	{
		if(objname[0] != '@')
			relevant_object = elements.findShapeByName(objname);
		else
		{
			multi_rev_objname = objname;
			elements.multi_findShapeByName(objname, multi_relevant_object);
			multi = 1;
		}
	}
	void set_parameters(int times, int interval, int delay)
	{
		remaining_trigger_times = total_trigger_times = times;
		trigger_interval = interval;
		remaining_trigger_interval = 0;
		remaining_active_delay = activate_delay = delay;
	}
	void reset()
	{
		remaining_trigger_times = total_trigger_times;
		remaining_trigger_interval = 0;
		remaining_active_delay = activate_delay;
	}

};



class RegisteredActs {
public:
	recursive_mutex lock;
	vector<Animation*> animations;
	vector<Event*> events;
	void add_animation(Animation *p) { animations.push_back(p); }
	void add_event(Event *p) { events.push_back(p); }
	Animation *findAnimByName(const string &aname)
	{
		for (auto x : animations) if (x->name == aname) return x;
		return nullptr;
	}
	Event *findEventByName(const string &ename)
	{
		for (auto x : events) if (x->name == ename) return x;
		return nullptr;
	}
};

extern RegisteredActs acts;



class KeyMapping {
private:
	string invalid;
public:
	const int MAX_KEY = 255;
	int custom = 0;
	int debug = 0;
	vector<string> instofkey[256];
	vector<string> &forkey(int key);
};


extern KeyMapping keymap;


class Context {
public:
	Shape *current_condition_default;
};

extern Context context;