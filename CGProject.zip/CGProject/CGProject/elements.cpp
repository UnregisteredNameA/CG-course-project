#include "pch.h"
#include "elements.h"
#include <cmath>
#include <algorithm>


bool GlobalSettings::light_enabled = 1;

int GlobalSettings::background[4] = { 0,0,0,0 };

float GlobalSettings::perspective_far = 100;

string GlobalSettings::background_texture, GlobalSettings::cover_texture;


float *trans_to_array(std::initializer_list<float> src)
{
	float *f = new float[src.size() + 1];
	memset(f, 0, sizeof(float) * (src.size() + 1));
	int i = 0;
	for (auto it = src.begin(); it != src.end(); ++it)
	{
		f[i++] = *it;
	}
	return f;
}

inline bool valid_float_number(const string &s)
{
	int dotn = 0;
	for (int i = 0; i < s.size(); ++i)
	{
		if (s[i] == '.') dotn++;
		if (i == 0 && s[i] == '-') continue;
		if (!isdigit(s[i]) && s[i] != '.') return 0;
	}
	if (dotn > 1) return 0;
	return 1;
}

_Opt & _Opt::operator=(std::initializer_list<float> args)
{
	this->valid = 1;
	float *f = trans_to_array(args);
	r = f[0];
	g = f[1];
	b = f[2];
	a = f[3];
	return *this;
}


Point3d operator+(const Point3d &a, const Point3d &b)
{
	return Point3d(a.x + b.x, a.y + b.y, a.z + b.z);
}

Point3d operator-(const Point3d &a, const Point3d &b)
{
	return Point3d(a.x - b.x, a.y - b.y, a.z - b.z);
}


void Material::set_default_material()
{
	float a[4] = { 1,1,1,1 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, a);

	float b[4] = { 0,0,0,1 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, b);

	float c[4] = { 1,1,1,1 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, c);

	float d[4] = { 220.0 / 255, 70.0 / 255, 0, 1 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, d);

	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 1);
}

void Material::operator()()
{
	if (ambient.valid)
	{
		float a[4] = { ambient.r, ambient.g, ambient.b, ambient.a };
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, a);
	}
	if (specular.valid)
	{
		float b[4] = { specular.r, specular.g, specular.b, specular.a };
		glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, b);
	}
	if (diffuse.valid)
	{
		float c[4] = { diffuse.r, diffuse.g, diffuse.b, diffuse.a };
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, c);
	}
	if (emission.valid)
	{
		float d[4] = { emission.r, emission.g, emission.b, emission.a };
		glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, d);
	}
	if(shininess_valid)
		glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
}

void Material::set_color_while_light_enabled(float r, float g, float b, float a)
{
	float aa[4] = { r,g,b,a };
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, aa);
	float cc[4] = { r,g,b,a };
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, cc);

	float bb[4] = { 0,0,0,1 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, bb);
	float dd[4] = { 0,0,0,1 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, dd);

	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 0);
}

string Material::to_string()
{
	string ret;
	if (name.size())
		ret += "material " + name + '\n';
	if (ambient.valid)
	{
		char ch[50];
		memset(ch, 0, sizeof(ch));
		sprintf_s(ch, 50, "ambient %f %f %f %f ", ambient.r, ambient.g, ambient.b, ambient.a);
		ret += ch;
	}
	if (specular.valid)
	{
		char ch[50];
		memset(ch, 0, sizeof(ch));
		sprintf_s(ch, 50, "specular %f %f %f %f ", specular.r, specular.g, specular.b, specular.a);
		ret += ch;
	}
	if (diffuse.valid)
	{
		char ch[50];
		memset(ch, 0, sizeof(ch));
		sprintf_s(ch, 50, "diffuse %f %f %f %f ", diffuse.r, diffuse.g, diffuse.b, diffuse.a);
		ret += ch;
	}
	if (emission.valid)
	{
		char ch[50];
		memset(ch, 0, sizeof(ch));
		sprintf_s(ch, 50, "emission %f %f %f %f ", emission.r, emission.g, emission.b, emission.a);
		ret += ch;
	}
	if (shininess_valid) ret += "shininess " + ::to_string(shininess);
	if(name.size()) ret += ";\n\n";
	return ret;
}

int Light::light_cnt = 0;

Light::Light()
{
	trackon = nullptr;
	if (light_cnt >= 7) throw std::logic_error("No more light can be created!");
	light_cnt++;
	glLightNo = GL_LIGHT0 + light_cnt - 1;
}

void Light::set_pos(std::initializer_list<float> pos)
{
	float *f = trans_to_array(pos);
	x = f[0]; y = f[1]; z = f[2];
}

void Light::set_lighting()
{
	if (edited)
	{
		edited = 0;

		float pos[4] = { x, y, z, 1 };

		if (trackon != nullptr)
			trackon->coord_originate_from_this_object();

		glLightfv(glLightNo, GL_POSITION, pos);

		if (trackon != nullptr)
			trackon->coord_reset();

		if (ambient.valid)
		{
			float a[4] = { ambient.r, ambient.g, ambient.b, ambient.a };
			glLightfv(glLightNo, GL_AMBIENT, a);
		}

		if (specular.valid)
		{
			float b[4] = { specular.r, specular.g, specular.b, specular.a };
			glLightfv(glLightNo, GL_SPECULAR, b);
		}

		if (diffuse.valid)
		{
			float c[4] = { diffuse.r, diffuse.g, diffuse.b, diffuse.a };
			glLightfv(glLightNo, GL_DIFFUSE, c);
		}
	}
	if (this->on)
		glEnable(glLightNo);
	else
		glDisable(glLightNo);
}

string Light::to_string()
{
	string ret;
	ret += "light++ " + ::to_string(this->id) + '\n';
	ret += "pos " + ::to_string(x) + ' ' +  ::to_string(y) + ' '+ ::to_string(z) + '\n';
	if (ambient.valid)
	{
		char ch[50];
		memset(ch, 0, sizeof(ch));
		sprintf_s(ch, 50, "ambient %f %f %f %f ", ambient.r, ambient.g, ambient.b, ambient.a);
		ret += ch;
	}
	if (specular.valid)
	{
		char ch[50];
		memset(ch, 0, sizeof(ch));
		sprintf_s(ch, 50, "specular %f %f %f %f ", specular.r, specular.g, specular.b, specular.a);
		ret += ch;
	}
	if (diffuse.valid)
	{
		char ch[50];
		memset(ch, 0, sizeof(ch));
		sprintf_s(ch, 50, "diffuse %f %f %f %f ", diffuse.r, diffuse.g, diffuse.b, diffuse.a);
		ret += ch;
	}
	ret += ";\n\n";
	return ret;
}


int Shape::shape_count = 0;

void Shape::init()
{
	GLuint sphere_list = glGenLists(1);
	float x[100], y[100];
	int i = 0, r = 1;
	glNewList(sphere_list, GL_COMPILE);
	for (i = 0; i <= 90; ++i)
	{
		double rad = 3.14159265359 / 90 * i;
		x[i] = sin(rad) * r;
		y[i] = cos(rad) * r;
	}
	myRevolutionSurface(180, 90, x, y, 1, 180);
	glEndList();
	Sphere::listno = sphere_list;

	GLuint cylinder_list = glGenLists(1);


}

void Shape::set_translate(float x, float y, float z)
{
	translate = 1;
	translatex = x;
	translatey = y;
	translatez = z;
}

void Shape::set_delta_translate(float dx, float dy, float dz)
{
	translate = 1;
	translatex += dx;
	translatey += dy;
	translatez += dz;
}

void Shape::set_rotate(float deg, float x, float y, float z)
{
	rotate = 1;
	rotatedeg = deg;
	rotatex = x;
	rotatey = y;
	rotatez = z;
}

void Shape::set_delta_rotate(float deg)
{
	rotatedeg += deg;
}

void Shape::set_self_rotate(float deg, float x, float y, float z)
{
	self_rotate = 1;
	selfrotatedeg = deg;
	selfrotatex = x;
	selfrotatey = y;
	selfrotatez = z;
}

void Shape::set_delta_self_rotate(float deg)
{
	selfrotatedeg += deg;
}


void Shape::set_scale(float x, float y, float z)
{
	scale = 1;
	scalex = x;
	scaley = y;
	scalez = z;
}

void Shape::set_delta_scale(float dx, float dy, float dz)
{
	scale = 1;
	scalex += dx;
	scaley += dy;
	scalez += dz;
}

void Shape::set_multiple_scale(float x, float y, float z)
{
	scale = 1;
	scalex *= x;
	scaley *= y;
	scalez *= z;
}

void Shape::set_color(float r, float g, float b, float a)
{
	color = 1;
	material = 0;
	red = r; green = g; blue = b; alpha = a;
}

void Shape::replace_entire_func(std::function<void()> f)
{
	completeFunc = f;
}

void Shape::replace_preprocess_func(std::function<void()> f)
{
	preprocess = f;
}

void Shape::replace_texture_func(std::function<void()> f)
{
	textureFunc = f;
}

void Shape::set_texture_name(const string & name)
{
	this->texturename = name;
}

void Shape::set_texture_id(int x)
{
	textureid = x;
}

void Shape::set_material_name(const string & name)
{
	this->materialname = name;
}

void Shape::replace_material_func(std::function<void()> f)
{
	material = 1;
	color = 0;
	materialFunc = f;
	materialFuncVec.clear();
	materialTraits.clear();
}

void Shape::add_material_trait(const string & str)
{
	materialTraits.push_back(str);
}

void Shape::add_material_func(std::function<void()> f)
{
	material = 1;
	color = 0;
	materialFunc = nullptr;
	materialFuncVec.push_back(f);
}

void Shape::rotate_translate_scale()
{
	if (rotate) glRotatef(rotatedeg, rotatex, rotatey, rotatez);
	if (translate) glTranslatef(translatex, translatey, translatez);
	if (scale) glScalef(scalex, scaley, scalez);
	if (self_rotate) glRotatef(selfrotatedeg, selfrotatex, selfrotatey, selfrotatez);
}


void Shape::copy_track_stack_of(Shape * which)
{
	this->coord_track_stack = which->coord_track_stack;
}

void Shape::clear_track_stack()
{
	this->coord_track_stack.clear();
}

void Shape::add_to_stack(Shape * which)
{
	this->coord_track_stack.push_back(which);
}

void Shape::coord_push_previous_matrixes()
{
	for (auto it = coord_track_stack.begin(); it != coord_track_stack.end(); ++it)
	{
		(*it)->rotate_translate_scale();
		glPushMatrix();
	}
}

void Shape::coord_pop_previous_matrixes()
{
	for (int i = 0; i < coord_track_stack.size(); ++i) glPopMatrix();
}

void Shape::coord_originate_from_this_object()
{
	coord_push_previous_matrixes();
	rotate_translate_scale();
	glPushMatrix();
}

void Shape::coord_reset()
{
	glPopMatrix();
	coord_pop_previous_matrixes();
}

void Shape::draw() 
{
	if (this->hide) return;

	glPushMatrix();

	/* If the whole draw function is redefined */
	if (completeFunc != nullptr)
	{
		completeFunc();
		return;
	}
	/* If preprocess function is defined */
	if (preprocess != nullptr) preprocess();

	/* Set the material */
	if (material)
	{
		if (materialFunc != nullptr)
			materialFunc();
		else if (materialFuncVec.size() > 0)
		{
			Material::set_default_material();
			for (auto it = materialFuncVec.begin(); it != materialFuncVec.end(); ++it) (*it)();
		}
		else Material::set_default_material();
	}

	/* Position, Rotation, Scale*/
	coord_push_previous_matrixes();
	rotate_translate_scale();

	/* Color */
	if (color)
	{
		if (GlobalSettings::light_enabled == false)
			glColor4f(red, green, blue, alpha);
		else
			Material::set_color_while_light_enabled(red, green, blue, alpha);
	}

	/* Set the texture */
	if (textureFunc != nullptr)
		textureFunc();
	else
		glBindTexture(GL_TEXTURE_2D, textureid);


	/* Draw */
	specific_draw();

	coord_pop_previous_matrixes();

	glPopMatrix();
}

void Shape::set_state(int state)
{
	this->state = state;
}

void Shape::set_delta_state(int delta)
{
	this->state += delta;
}

int Shape::get_state()
{
	return state;
}

void Shape::to_string(string &buf)
{
	buf.clear();
	string ws(" "), ln = "\n";
	string beginwith = this->hide ? "obj " : "obj++ ";
	buf += beginwith + this->name + ' ';
	string specificstr = specific_to_string();
	buf += specificstr;
	buf += '\n';
	if (coord_track_stack.size()) buf += string("track") + ws + coord_track_stack[coord_track_stack.size() - 1]->name + ln; //track
	buf += "translate" + ws + ::to_string(translatex) + ws + ::to_string(translatey) + ws + ::to_string(translatez) + ln; //pos
	buf += "scale" + ws + ::to_string(scalex) + ws + ::to_string(scaley) + ws + ::to_string(scalez) + ln;  //scale
	if(rotate) buf += "rotate" + ws + ::to_string(rotatedeg) + ws + ::to_string(rotatex) + ws + ::to_string(rotatey) + ws + ::to_string(rotatez) + ln; //rotate
	if(self_rotate) buf += "selfrotate" + ws + ::to_string(selfrotatedeg) + ws + ::to_string(selfrotatex) + ws + ::to_string(selfrotatey) + ws + ::to_string(selfrotatez) + ln;
	if (color)
		buf += "color" + ws + ::to_string(red) + ws + ::to_string(green) + ws + ::to_string(blue) + ws + ::to_string(alpha);
	else
	{
		if (materialFunc != nullptr)
			buf += "material " + materialname;
		else if (materialFuncVec.size())
		{
			for (string x : materialTraits) buf += x;
		}
	}
	buf += ln;
	if (textureFunc != nullptr || textureid != 0)
		buf += "texture " + texturename;
	buf += ";\n\n";
}


Point3d Shape::absolute_coordinate()
{
	glm::vec4 point(0, 0, 0, 1);
	glm::mat4 matrix = glm::mat4(1.0f);
	for (auto it = coord_track_stack.begin(); it != coord_track_stack.end(); ++it)
	{
		glm::vec3 vec;
		if ((*it)->rotate)
		{
			vec = glm::vec3((*it)->rotatex, (*it)->rotatey, (*it)->rotatez);
			matrix = glm::rotate(matrix, (*it)->rotatedeg / 360.0f * 2.0f * 3.14159265359f, vec);
		}
		if ((*it)->translate)
		{
			vec = glm::vec3((*it)->translatex, (*it)->translatey, (*it)->translatez);
			matrix = glm::translate(matrix, vec);
		}
		if ((*it)->scale)
		{
			vec = glm::vec3((*it)->scalex, (*it)->scaley, (*it)->scalez);
			matrix = glm::scale(matrix, vec);
		}
		if ((*it)->self_rotate)
		{
			vec = glm::vec3((*it)->selfrotatex, (*it)->selfrotatey, (*it)->selfrotatez);
			matrix = glm::rotate(matrix, (*it)->selfrotatedeg / 360.0f * 2.0f * 3.14159265359f, vec);
		}
	}
	glm::vec4 res;

	glm::vec3 vec = glm::vec3(this->rotatex, this->rotatey, this->rotatez);
	if (this->rotate)
	{
		vec = glm::vec3(this->rotatex, this->rotatey, this->rotatez);
		float rad = (float)(this->rotatedeg / 360.0 * 2 * 3.14159265359);
		matrix = glm::rotate(matrix, rad, vec);
	}
	if (this->translate)
	{
		vec = glm::vec3(this->translatex, this->translatey, this->translatez);
		matrix = glm::translate(matrix, vec);
	}
	if (this->scale)
	{
		vec = glm::vec3(this->scalex, this->scaley, this->scalez);
		matrix = glm::scale(matrix, vec);
	}
	if (this->self_rotate)
	{
		vec = glm::vec3(this->selfrotatex, this->selfrotatey, this->selfrotatez);
		matrix = glm::rotate(matrix, this->selfrotatedeg / 360.0f * 2.0f * 3.14159265359f, vec);
	}
	res = matrix * point;
	Point3d ret;
	ret.x = res.x;
	ret.y = res.y;
	ret.z = res.z;
	return ret;
}




void NullObject::specific_draw()
{
	return;
}

string NullObject::specific_to_string()
{
	return "null";
}

float NullObject::collide_radius()
{
	return 0;
}



void myCube(float a)
{
	glPushMatrix();
	glNormal3f(0, 0, 1);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3f(-a/2, -a/2, a/2);
	glTexCoord2f(1.0, 0.0); glVertex3f(a/2, -a/2, a/2);
	glTexCoord2f(1.0, 1.0); glVertex3f(a/2, a/2, a/2);
	glTexCoord2f(0.0, 1.0); glVertex3f(-a/2, a/2, a/2);
	glEnd();

	glNormal3f(0, 0, -1);
	glBegin(GL_QUADS);
	glTexCoord2f(1.0, 0.0); glVertex3f(-a/2, -a/2, -a/2);
	glTexCoord2f(1.0, 1.0); glVertex3f(-a/2, a/2, -a/2);
	glTexCoord2f(0.0, 1.0); glVertex3f(a/2, a/2, -a/2);
	glTexCoord2f(0.0, 0.0); glVertex3f(a/2, -a/2, -a/2);
	glEnd();

	glNormal3f(0, 1, 0);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 1.0); glVertex3f(-a/2, a/2, -a/2);
	glTexCoord2f(0.0, 0.0); glVertex3f(-a/2, a/2, a/2);
	glTexCoord2f(1.0, 0.0); glVertex3f(a/2, a/2, a/2);
	glTexCoord2f(1.0, 1.0); glVertex3f(a/2, a/2, -a/2);
	glEnd();

	glNormal3f(0, -1, 0);
	glBegin(GL_QUADS);
	glTexCoord2f(1.0, 1.0); glVertex3f(-a/2, -a/2, -a/2);
	glTexCoord2f(0.0, 1.0); glVertex3f(a/2, -a/2, -a/2);
	glTexCoord2f(0.0, 0.0); glVertex3f(a/2, -a/2, a/2);
	glTexCoord2f(1.0, 0.0); glVertex3f(-a/2, -a/2, a/2);
	glEnd();

	glNormal3f(1, 0, 0);
	glBegin(GL_QUADS);
	glTexCoord2f(1.0, 0.0); glVertex3f(a/2, -a/2, -a/2);
	glTexCoord2f(1.0, 1.0); glVertex3f(a/2, a/2, -a/2);
	glTexCoord2f(0.0, 1.0); glVertex3f(a/2, a/2, a/2);
	glTexCoord2f(0.0, 0.0); glVertex3f(a/2, -a/2, a/2);
	glEnd();

	glNormal3f(-1, 0, 0);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3f(-a/2, -a/2, -a/2);
	glTexCoord2f(1.0, 0.0); glVertex3f(-a/2, -a/2, a/2);
	glTexCoord2f(1.0, 1.0); glVertex3f(-a/2, a/2, a/2);
	glTexCoord2f(0.0, 1.0); glVertex3f(-a/2, a/2, -a/2);
	glEnd();
	glPopMatrix();

}

Point3d cross_product(float l, float m, float n, float o, float p, float q)
{
	Point3d ret;
	ret.x = m * q - n * p;
	ret.y = n * o - l * q;
	ret.z = l * p - m * o;
	return ret;
}

Point3d normalize(Point3d vecx)
{
	Point3d vec = vecx;
	float ww = sqrt(vec.x*vec.x + vec.y*vec.y + vec.z*vec.z);
	vec.x = vec.x / ww;
	vec.y = vec.y / ww;
	vec.z = vec.z / ww;
	return vec;
}

//layerp + 1 numbers should be inside x and y arrays, y strictly decrease.
void myRevolutionSurface(int rotp, int layerp, float *x, float *y, int triangle, float requested_degree_per_texture)
{
	int face_per_texture = rotp / 4;
	if (face_per_texture == 0) face_per_texture = 1;
	//float 
	float degree_per_texture = 360.0 / (rotp / face_per_texture);
	if (requested_degree_per_texture != -1) degree_per_texture = requested_degree_per_texture;
	auto fmod = [](float a, float b) -> float { while (a > b) a -= b; return a; };

	float rotdeg = 360 / rotp;
	for (float deg = 0; deg < 360; deg += rotdeg)
	{
		float nextdeg = (deg + rotdeg);
		float rad = deg / 360.0 * 2 * 3.14159265359;
		float nextrad = (deg + rotdeg) / 360.0 * 2 * 3.14159265359;
		glBegin(GL_TRIANGLES);
		
		//top
		glNormal3f(0, 1, 0);
		glTexCoord2f(0.5, 0.5); 
		glVertex3f(0, y[0], 0);
		glTexCoord2f(0.5 + 0.5 * cos(rad), 0.5 - 0.5 * sin(rad)); 
		glVertex3f(x[0] * cos(rad), y[0], x[0] * sin(rad));
		glTexCoord2f(0.5 + 0.5 * cos(nextrad), 0.5 - 0.5 * sin(nextrad)); 
		glVertex3f(x[0] * cos(nextrad), y[0], x[0] * sin(nextrad));

		//buttom
		glNormal3f(0, -1, 0);
		glTexCoord2f(0.5, 0.5);
		glVertex3f(0, y[layerp], 0);
		glTexCoord2f(0.5 + 0.5 * cos(rad), 0.5 - 0.5 * sin(rad));
		glVertex3f(x[layerp] * cos(rad), y[layerp], x[layerp] * sin(rad));
		glTexCoord2f(0.5 + 0.5 * cos(nextrad), 0.5 - 0.5 * sin(nextrad));
		glVertex3f(x[layerp] * cos(nextrad), y[layerp], x[layerp] * sin(nextrad));

		//side
		for (int seg = 0; seg < layerp; ++seg)
		{
			Point3d A, B, C, D;
			/*
			+1   0
			B----A
			|   /|
 			|  / |
			| /  |
			|/   |
			C----D	
			*/
			A.x = x[seg] * cos(rad); 
			A.y = y[seg];
			A.z = x[seg] * sin(rad);
			B.x = x[seg] * cos(nextrad); 
			B.y = y[seg];
			B.z = x[seg] * sin(nextrad);
			C.x = x[seg + 1] * cos(nextrad);
			C.y = y[seg + 1];
			C.z = x[seg + 1] * sin(nextrad);
			D.x = x[seg + 1] * cos(rad);
			D.y = y[seg + 1];
			D.z = x[seg + 1] * sin(rad);

			if (triangle)
			{
				float thistexX = fmod(deg, degree_per_texture - 0.125) / degree_per_texture;
				float nexttexX = fmod(nextdeg, degree_per_texture + 0.125) / degree_per_texture;
				//ACB
				Point3d Nabc;
				Nabc = cross_product(B.x - A.x, B.y - A.y, B.z - A.z, C.x - A.x, C.y - A.y, C.z - A.z);
				Nabc = normalize(Nabc);
				glNormal3f(Nabc.x, Nabc.y, Nabc.z);

				glTexCoord2f(thistexX, (y[seg] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(A.x, A.y, A.z);

				glTexCoord2f(nexttexX, (y[seg] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(B.x, B.y, B.z);

				glTexCoord2f(nexttexX, (y[seg + 1] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(C.x, C.y, C.z);

				//ACD
				Point3d Nacd;
				Nacd = cross_product(C.x - A.x, C.y - A.y, C.z - A.z, D.x - A.x, D.y - A.y, D.z - A.z);
				Nacd = normalize(Nacd);
				glNormal3f(Nacd.x, Nacd.y, Nacd.z);

				glTexCoord2f(thistexX, (y[seg] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(A.x, A.y, A.z);

				glTexCoord2f(thistexX, (y[seg + 1] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(D.x, D.y, D.z);

				glTexCoord2f(nexttexX, (y[seg + 1] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(C.x, C.y, C.z);
			}
			else
			{
				glEnd();
				glBegin(GL_QUADS);

				Point3d Nabc;
				Nabc = cross_product(B.x - A.x, B.y - A.y, B.z - A.z, C.x - A.x, C.y - A.y, C.z - A.z);
				if (Nabc.x <= 1e-7 && Nabc.y <= 1e-7 && Nabc.z <= 1e-7)
					Nabc = cross_product(C.x - A.x, C.y - A.y, C.z - A.z, D.x - A.x, D.y - A.y, D.z - A.z);
				Nabc = normalize(Nabc);
				glNormal3f(Nabc.x, Nabc.y, Nabc.z);

				float thistexX = fmod(deg, degree_per_texture - 0.125) / degree_per_texture;
				float nexttexX = fmod(nextdeg, degree_per_texture) / (degree_per_texture + 0.125);

				glTexCoord2f(thistexX, (y[seg] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(A.x, A.y, A.z);

				glTexCoord2f(nexttexX, (y[seg] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(B.x, B.y, B.z);

				glTexCoord2f(nexttexX, (y[seg + 1] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(C.x, C.y, C.z);

				glTexCoord2f(thistexX, (y[seg + 1] - y[layerp]) / (y[0] - y[layerp]));
				glVertex3f(D.x, D.y, D.z);

				glEnd();
				glBegin(GL_TRIANGLES);
			}
			
		}
		glEnd();
	}
}


void Cube::specific_draw()
{
	myCube(a);
}

string Cube::specific_to_string()
{
	return string("cube ") + ::to_string(a);
}

void Cube::set_attribute(std::initializer_list<float> at)
{
	shoulddelete = 1;
	set_attribute_delete(trans_to_array(at));
}

void Cube::set_attribute(float *at)
{
	a = at[0];
}

float Cube::collide_radius()
{
	return a * sqrt(3) * 0.5;
}



void Cuboid::specific_draw()
{
	glPushMatrix();
	glScalef(xa, ya, za);
	myCube(1);
	glPopMatrix();
}

string Cuboid::specific_to_string()
{
	return string("cuboid ") + ::to_string(xa) + ' ' + ::to_string(ya) + ' ' +::to_string(za);
}

void Cuboid::set_attribute(std::initializer_list<float> at)
{
	set_attribute_delete(trans_to_array(at));
}

void Cuboid::set_attribute(float *at)
{
	xa = at[0]; ya = at[1]; za = at[2];
}

float Cuboid::collide_radius()
{
	return sqrt(xa * xa * 0.25 + ya * ya * 0.25 + za * za * 0.25);
}



GLuint Sphere::listno;

void Sphere::specific_draw()
{
	glPushMatrix();
	glScalef(r, r, r);
	glCallList(Sphere::listno);
	glPopMatrix();
}

string Sphere::specific_to_string()
{
	return string("sphere ") + ::to_string(r);
}

void Sphere::set_attribute(std::initializer_list<float> at)
{
	set_attribute_delete(trans_to_array(at));
}

void Sphere::set_attribute(float *at)
{
	r = at[0];
}

float Sphere::collide_radius()
{
	return r;
}



void Cone::specific_draw()
{
	float x[100], y[100];
	int i = 0;
	for (i = 0; i <= 5; ++i)
	{
		double rad = 3.14159265359 / 5.0 * i;
		x[i] = this->b / 5.0 * i;
		y[i] = h / 2.0 - h / 5.0 * i;
	}
	myRevolutionSurface(90, 5, x, y, 0);
}

string Cone::specific_to_string()
{
	return string("cone ") + ::to_string(this->b) + ' ' + ::to_string(h);
}

void Cone::set_attribute(std::initializer_list<float> at)
{
	set_attribute_delete(trans_to_array(at));
}

void Cone::set_attribute(float *at)
{
	b = at[0]; h = at[1];
}

float Cone::collide_radius()
{
	return sqrt(b*b + 0.25*h*h);
}



void draw_circle(float cx, float cy, float cz, float r, int num_segments)
{
	GLfloat vertex[4];

	const GLfloat drad = 2.0*3.14159 / num_segments;
	glBegin(GL_TRIANGLE_FAN);

	vertex[0] = cx;
	vertex[1] = cy;
	vertex[2] = cz;
	vertex[3] = 1.0;
	glVertex4fv(vertex);

	for (int i = 0; i < num_segments; i++)
	{
		vertex[0] = std::cos(drad*i) * r + cx;
		vertex[1] = std::sin(drad*i) * r + cy;
		vertex[2] = cz;
		vertex[3] = 1.0;
		glVertex4fv(vertex);
	}

	vertex[0] = 1.0 * r + cx;
	vertex[1] = 0.0 * r + cy;
	vertex[2] = cz;
	vertex[3] = 1.0;
	glVertex4fv(vertex);
	glEnd();
}

void Cylinder::specific_draw()
{
	const int nn = 3;
	float x[nn + 5], y[nn + 5];
	int i = 0;
	for (i = 0; i <= nn; ++i)
	{
		double rad = 3.14159265359 / (float)nn * i;
		x[i] = rtop + (rbtm-rtop) / (float)nn * i;
		y[i] = h / 2.0 - h / (float)nn * i;
	}
	myRevolutionSurface(90, nn, x, y, 0);
}

string Cylinder::specific_to_string()
{
	return string("cylinder ") + ::to_string(rbtm) + ' ' + ::to_string(rtop) + ' ' + ::to_string(h);
}

void Cylinder::set_attribute(std::initializer_list<float> at)
{
	set_attribute_delete(trans_to_array(at));
}

void Cylinder::set_attribute(float *at)
{
	rbtm = at[0]; rtop = at[1]; h = at[2];
}

float Cylinder::collide_radius()
{
	int rr = max(rbtm, rtop);
	return sqrt(rr*rr + h*h*0.25);
}


void Prism::specific_draw()
{
	float x[2] = { rtop, rbtm }, y[2] = {h/2.0, -h/2.0};
	
	myRevolutionSurface((int)n, 1, x, y, 0);
}

string Prism::specific_to_string()
{
	return string("prism ") + ::to_string(n) + ' ' + ::to_string(rbtm) + ' ' + ::to_string(rtop) + ' ' + ::to_string(h);
}


void Prism::set_attribute(std::initializer_list<float> at)
{
	set_attribute_delete(trans_to_array(at));
}

void Prism::set_attribute(float *at)
{
	n = at[0]; rbtm = at[1]; rtop = at[2]; h = at[3];
}

float Prism::collide_radius()
{
	int rr = max(rbtm, rtop);
	return sqrt(rr*rr + 0.25*h*h);
}


void Pyramid::specific_draw()
{
	float x[2] = { 0, r }, y[2] = { h / 2.0, -h / 2.0 };
	myRevolutionSurface((int)n, 1, x, y, 0);
}

string Pyramid::specific_to_string()
{
	return string("pyramid ") + ::to_string(n) + ' ' + ::to_string(r) + ' ' + ::to_string(h);
}

void Pyramid::set_attribute(std::initializer_list<float> at)
{
	set_attribute_delete(trans_to_array(at));
}

void Pyramid::set_attribute(float *at)
{
	n = at[0]; r = at[1]; h = at[2];
}

float Pyramid::collide_radius()
{
	return sqrt(r*r + 0.25*h*h);
}


bool ObjFile::load_file(const string & fn)
{
	this->filename = fn;
	ifstream file(fn);
	type = 1;
	string line;
	while (getline(file, line))
	{
		if (line.substr(0, 2) == "vt" || line.substr(0, 2) == "vn")
		{
			cout << "Obj type 2" << endl;
			file.close();
			vSets.clear();
			return load_type2(fn);
		}
		else if (line.substr(0, 1) == "v")
		{
			vector<GLfloat> Point;
			GLfloat x, y, z;
			istringstream s(line.substr(2));
			s >> x; s >> y; s >> z;
			Point.push_back(x);
			Point.push_back(y);
			Point.push_back(z);
			vSets.push_back(Point);
		}
		else if (line.substr(0, 1) == "f")
		{
			vector<GLint> vIndexSets;
			GLint u, v, w;
			istringstream vtns(line.substr(2));
			vtns >> u; vtns >> v; vtns >> w;
			if (!vtns.eof())
			{
				cout << "Obj type 2" << endl;
				vSets.clear();
				file.close();
				return load_type2(fn);
			}
			vIndexSets.push_back(u - 1);
			vIndexSets.push_back(v - 1);
			vIndexSets.push_back(w - 1);
			fSets.push_back(vIndexSets);
		}
	}
	file.close();
	return true;
}
bool ObjFile::load_type2(const string & fn)
{
	std::vector<unsigned int> vertexIndices, normalIndices;
	std::vector<glm::vec3> temp_vertices;
	std::vector<glm::vec3> temp_normals;

	FILE * file = fopen(fn.c_str(), "r");
	if (file == NULL) {
		printf("ERROR: Can not open file!\n");
		return false;
	}
	type = 2;
	while (1) {

		char lineHeader[128];
		int res = fscanf(file, "%s", lineHeader);
		if (res == EOF)
			break;
		if (strcmp(lineHeader, "v") == 0) {
			glm::vec3 vertex;
			fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z);
			temp_vertices.push_back(vertex);
		}
		else if (strcmp(lineHeader, "vt") == 0) {
			glm::vec2 uv;
			fscanf(file, "%f %f\n", &uv.x, &uv.y);
			//Do not support texture.
		}
		else if (strcmp(lineHeader, "vn") == 0) {
			glm::vec3 normal;
			fscanf(file, "%f %f %f\n", &normal.x, &normal.y, &normal.z);
			temp_normals.push_back(normal);
		}
		else if (strcmp(lineHeader, "f") == 0) {
			std::string vertex1, vertex2, vertex3;
			unsigned int vertexIndex[3], uvIndex[3], normalIndex[3];
			int matches = fscanf(file, "%d//%d %d//%d %d//%d\n", &vertexIndex[0], &normalIndex[0], &vertexIndex[1], &normalIndex[1], &vertexIndex[2], &normalIndex[2]);
			if (matches != 6) {
				type = 3;
				cout << "ERROR: Obj type not supported!" << endl;
				return false;
			}
			vertexIndices.push_back(vertexIndex[0]);
			vertexIndices.push_back(vertexIndex[1]);
			vertexIndices.push_back(vertexIndex[2]);
			normalIndices.push_back(normalIndex[0]);
			normalIndices.push_back(normalIndex[1]);
			normalIndices.push_back(normalIndex[2]);
		}
		else {
			char stupidBuffer[1000];
			fgets(stupidBuffer, 1000, file);
		}
	}
	for (unsigned int i = 0; i < vertexIndices.size(); i++) {

		unsigned int vertexIndex = vertexIndices[i];
		unsigned int normalIndex = normalIndices[i];
		glm::vec3 vertex = temp_vertices[vertexIndex - 1];
		glm::vec3 normal = temp_normals[normalIndex - 1];
		vertices.push_back(vertex);
		normals.push_back(normal);
	}
	return true;
}

string ObjFile::specific_to_string()
{
	return string("objfile ") + filename;
}


void ObjFile::specific_draw()
{
	//cout << "Obj type:" << type << endl;
	if (type == 3)
	{
		cout << "ERROR: Obj type not supported!" << endl;
		return;
	}
	else if (type == 2)
	{
		glBegin(GL_TRIANGLES);
		for (int i = 0; i < vertices.size(); i++)
		{
			glNormal3f(normals[i].x, normals[i].y, normals[i].z);
			glVertex3f(vertices[i].x, vertices[i].y, vertices[i].z);
		}
		glEnd();
		return;
	}
	else if (type == 1)
	{
		glBegin(GL_TRIANGLES);//��ʼ����
		for (int i = 0; i < fSets.size(); i++) {
			GLfloat VN[3];
			//��������
			GLfloat SV1[3];
			GLfloat SV2[3];
			GLfloat SV3[3];

			GLint firstVertexIndex = (fSets[i])[0];//ȡ����������
			GLint secondVertexIndex = (fSets[i])[1];
			GLint thirdVertexIndex = (fSets[i])[2];

			SV1[0] = (vSets[firstVertexIndex])[0];//��һ������
			SV1[1] = (vSets[firstVertexIndex])[1];
			SV1[2] = (vSets[firstVertexIndex])[2];

			SV2[0] = (vSets[secondVertexIndex])[0]; //�ڶ�������
			SV2[1] = (vSets[secondVertexIndex])[1];
			SV2[2] = (vSets[secondVertexIndex])[2];

			SV3[0] = (vSets[thirdVertexIndex])[0]; //����������
			SV3[1] = (vSets[thirdVertexIndex])[1];
			SV3[2] = (vSets[thirdVertexIndex])[2];

			GLfloat vec1[3], vec2[3], vec3[3];//���㷨����
			//(x2-x1,y2-y1,z2-z1)
			vec1[0] = SV1[0] - SV2[0];
			vec1[1] = SV1[1] - SV2[1];
			vec1[2] = SV1[2] - SV2[2];

			//(x3-x2,y3-y2,z3-z2)
			vec2[0] = SV1[0] - SV3[0];
			vec2[1] = SV1[1] - SV3[1];
			vec2[2] = SV1[2] - SV3[2];

			//(x3-x1,y3-y1,z3-z1)
			vec3[0] = vec1[1] * vec2[2] - vec1[2] * vec2[1];
			vec3[1] = vec2[0] * vec1[2] - vec2[2] * vec1[0];
			vec3[2] = vec2[1] * vec1[0] - vec2[0] * vec1[1];

			GLfloat D = sqrt(pow(vec3[0], 2) + pow(vec3[1], 2) + pow(vec3[2], 2));

			VN[0] = vec3[0] / D;
			VN[1] = vec3[1] / D;
			VN[2] = vec3[2] / D;

			glNormal3f(VN[0], VN[1], VN[2]);//���Ʒ�����
			glVertex3f(SV1[0], SV1[1], SV1[2]);//����������Ƭ
			glVertex3f(SV2[0], SV2[1], SV2[2]);
			glVertex3f(SV3[0], SV3[1], SV3[2]);
		}
		glEnd();
	}
	return;
}

float ObjFile::collide_radius()
{
	return 0;
}



int ShapeEditor::expected_argnum(const string & cmd)
{
	if (cmd == "pos" || cmd == "position" || cmd == "translate") return 3;
	else if (cmd == "pos+" || cmd == "position+" || cmd == "translate+") return 3;
	else if (cmd == "rotate" || cmd == "selfrotate") return 4;
	else if (cmd == "rotate+" || cmd == "selfrotate+") return 1;
	else if (cmd == "scale") return 3;
	else if (cmd == "scale+") return 3;
	else if (cmd == "scale*") return 3;
	else if (cmd == "color") return 4;
	else if (cmd == "ambient") return 4;
	else if (cmd == "diffuse") return 4;
	else if (cmd == "specular") return 4;
	else if (cmd == "emission") return 4;
	else if (cmd == "shininess") return 1;
	else if (cmd == "material") return 1;
	else if (cmd == "texture") return 1;
	else if (cmd == "track") return 1;
	else if (cmd == "untrack") return 0;
	else if (cmd == "state" || cmd == "state+" || cmd == "statesetb1" || cmd == "statesetb0") return 1;
	else if (cmd == "posof") return 1;
	else if (cmd == "remove") return 0;
}

ShapeEditor::ShapeEditor(const string & str)
{
	int ifpos = str.find("if");
	int pos1, pos2 = 0;
	if (ifpos != string::npos && (str[ifpos + 2] == ' ' || str[ifpos + 2] == '(' || str[ifpos + 2] == '\n' || str[ifpos + 2] == '\t'))
	{
		pos1 = str.find('(') + 1;
		pos2 = str.find_last_of(')') - 1;
		int k;
		this->condition_str = str.substr(pos1, pos2 - pos1 + 1);
	}
	
	string body = pos2 != 0 ? str.substr(pos2 + 2) : str;
	stringstream ss(body);
	ss >> this->cmd;
	int expect = ShapeEditor::expected_argnum(this->cmd);
	if (expect > 0)
	{
		ss >> this->cmdi;
		if (valid_float_number(cmdi)) args.push_back(stof(cmdi));
		int expect = ShapeEditor::expected_argnum(this->cmd);
		for (int i = 0; i < expect - 1; ++i)
		{
			string tmp;
			ss >> tmp;
			if (valid_float_number(cmdi)) args.push_back(stof(tmp));
		}
	}
}

void ShapeEditor::operator()(Shape *p)
{
	if (condition_str.size() && cond == nullptr)
	{
		cond = new Condition(condition_str);
	}
	if (cond != nullptr)
	{
		if (!((*cond)(p))) return;
	}
	if (cmd == "pos" || cmd == "position" || cmd == "translate")
		p->set_translate(args[0], args[1], args[2]);
	else if (cmd == "pos+" || cmd == "position+" || cmd == "translate+")
		p->set_delta_translate(args[0], args[1], args[2]);
	else if (cmd == "rotate")
		p->set_rotate(args[0], args[1], args[2], args[3]);
	else if (cmd == "rotate+")
		p->set_delta_rotate(args[0]);
	else if (cmd == "scale")
		p->set_scale(args[0], args[1], args[2]);
	else if (cmd == "scale+")
		p->set_delta_scale(args[0], args[1], args[2]);
	else if (cmd == "scale*")
		p->set_multiple_scale(args[0], args[1], args[2]);
	else if (cmd == "color") 
		p->set_color(args[0], args[1], args[2], args[3]);
	else if (cmd == "ambient")
	{
		Material x;
		x.ambient = { args[0], args[1], args[2], args[3] };
		p->add_material_trait(x.to_string());
		p->add_material_func(x);
	}
	else if (cmd == "diffuse")
	{
		Material x;
		x.diffuse = { args[0], args[1], args[2], args[3] };
		p->add_material_trait(x.to_string());
		p->add_material_func(x);
	}
	else if (cmd == "specular")
	{
		Material x;
		x.specular = { args[0], args[1], args[2], args[3] };
		p->add_material_trait(x.to_string());
		p->add_material_func(x);
	}
	else if (cmd == "emission")
	{
		Material x;
		x.emission = { args[0], args[1], args[2], args[3] };
		p->add_material_trait(x.to_string());
		p->add_material_func(x);
	}
	else if (cmd == "shininess")
	{
		Material x;
		x.shininess_valid = 1;
		x.shininess = args[0];
		p->add_material_trait(x.to_string());
		p->add_material_func(x);
	}
	else if (cmd == "material")
	{
		Material *px = elements.findMaterialByName(cmdi);
		p->set_material_name(cmdi);
		p->replace_material_func(*px);
	}
	else if (cmd == "texture")
	{
		if (cmdi == "null")
		{
			p->replace_texture_func(nullptr);
			p->set_texture_id(0);
			return;
		}
		Texture *pt = elements.findTextureByName(cmdi);
		p->set_texture_name(cmdi);
		p->replace_texture_func(*pt);
		p->set_texture_id(pt->texture_id);
	}
	else if (cmd == "track")
	{
		Shape *which = elements.findShapeByName(cmdi);
		p->copy_track_stack_of(which);
		p->add_to_stack(which);
	}
	else if (cmd == "untrack")
		p->clear_track_stack();
	else if (cmd == "state")
		p->set_state((int)args[0]);
	else if (cmd == "state+")
		p->set_delta_state((int)args[0]);
	else if (cmd == "statesetb1")
		p->set_state(p->get_state() | (1 << (int)args[0]));
	else if (cmd == "statesetb0")
		p->set_state(p->get_state() & (~(1 << (int)args[0])));
	else if (cmd == "posof")
	{
		Point3d posd = elements.findShapeByName(cmdi)->absolute_coordinate();
		p->set_translate(posd.x, posd.y, posd.z);
	}
	else if (cmd == "remove")
	{
		elements.remove_shape_by_ptr(p);
	}
	else if (cmd == "selfrotate")
		p->set_self_rotate(args[0], args[1], args[2], args[3]);
	else if (cmd == "selfrotate+")
		p->set_delta_self_rotate(args[0]);
		
}



int LightEditor::expected_argnum(const string &cmd)
{
	if (cmd == "pos" || cmd == "position") return 3;
	else if (cmd == "pos+" || cmd == "position+") return 3;
	else if (cmd == "ambient") return 4;
	else if (cmd == "diffuse") return 4;
	else if (cmd == "specular") return 4;
	else if (cmd == "track") return 1;
	else if (cmd == "untrack") return 0;
	else if (cmd == "strength") return 1;
}

void LightEditor::operator()(Light *p)
{
	if (cmd == "pos" || cmd == "position") { p->x = args[0]; p->y = args[1]; p->z = args[2]; p->edited = 1; }
	else if (cmd == "pos+" || cmd == "position+") { p->x += args[0]; p->y += args[1]; p->z += args[2]; p->edited = 1; }
	else if (cmd == "strength") { p->ambient.factorof(args[0]); p->diffuse.factorof(args[0]); p->specular.factorof(args[0]); p->edited = 1; }
	else if (cmd == "ambient") { p->ambient = { args[0], args[1], args[2], args[3] }; p->edited = 1; }
	else if (cmd == "diffuse") { p->diffuse = { args[0], args[1], args[2], args[3] }; p->edited = 1; }
	else if (cmd == "specular") { p->specular = { args[0], args[1], args[2], args[3] }; p->edited = 1; }
	else if (cmd == "track") { Shape *which = elements.findShapeByName(cmdi); p->trackon = which; p->edited = 1; }
	else if (cmd == "untrack") { p->trackon = nullptr; }
}



unsigned int Texture::allocatedID[MAX_TEXTURE_NUM];

int Texture::alloc_i = 0;

void Texture::texture_init()
{
	glGenTextures(MAX_TEXTURE_NUM, allocatedID);
	alloc_i = 0;
}

unsigned char * Texture::LoadBitmapFile(const char * filename, BITMAPINFOHEADER * bitmapInfoHeader)
{
	FILE *filePtr;	// �ļ�ָ��
	BITMAPFILEHEADER bitmapFileHeader;	// bitmap�ļ�ͷ
	unsigned char	*bitmapImage;		// bitmapͼ������
	int	imageIdx = 0;		// ͼ��λ������
	unsigned char	tempRGB;	// ��������

								// �ԡ�������+����ģʽ���ļ�filename 
	filePtr = fopen(filename, "rb");
	if (filePtr == NULL) return NULL;
	// ����bitmap�ļ�ͼ
	fread(&bitmapFileHeader, sizeof(BITMAPFILEHEADER), 1, filePtr);
	// ��֤�Ƿ�Ϊbitmap�ļ�
	if (bitmapFileHeader.bfType != BITMAP_ID) {
		fprintf(stderr, "Error in LoadBitmapFile: the file is not a bitmap file\n");
		return NULL;
	}

	// ����bitmap��Ϣͷ
	fread(bitmapInfoHeader, sizeof(BITMAPINFOHEADER), 1, filePtr);
	// ���ļ�ָ������bitmap����
	fseek(filePtr, bitmapFileHeader.bfOffBits, SEEK_SET);
	// Ϊװ��ͼ�����ݴ����㹻���ڴ�
	bitmapImage = new unsigned char[bitmapInfoHeader->biSizeImage];
	// ��֤�ڴ��Ƿ񴴽��ɹ�
	if (!bitmapImage) {
		fprintf(stderr, "Error in LoadBitmapFile: memory error\n");
		return NULL;
	}

	// ����bitmapͼ������
	fread(bitmapImage, 1, bitmapInfoHeader->biSizeImage, filePtr);
	// ȷ�϶���ɹ�
	if (bitmapImage == NULL) {
		fprintf(stderr, "Error in LoadBitmapFile: memory error\n");
		return NULL;
	}

	//����bitmap�б���ĸ�ʽ��BGR�����潻��R��B��ֵ���õ�RGB��ʽ
	for (imageIdx = 0;
		imageIdx < bitmapInfoHeader->biSizeImage; imageIdx += 3) {
		tempRGB = bitmapImage[imageIdx];
		bitmapImage[imageIdx] = bitmapImage[imageIdx + 2];
		bitmapImage[imageIdx + 2] = tempRGB;
	}
	// �ر�bitmapͼ���ļ�
	fclose(filePtr);
	return bitmapImage;
}

unsigned char * Texture::LoadBitmapFile_whiteToAlpha(const char * filename, BITMAPINFOHEADER * bitmapInfoHeader)
{
	FILE *filePtr;	
	BITMAPFILEHEADER bitmapFileHeader;
	unsigned char	*bitmapImage;	
	int	imageIdx = 0;		
	unsigned char	tempRGB;	

	filePtr = fopen(filename, "rb");
	if (filePtr == NULL) return NULL;
	fread(&bitmapFileHeader, sizeof(BITMAPFILEHEADER), 1, filePtr);
	if (bitmapFileHeader.bfType != BITMAP_ID) {
		fprintf(stderr, "Error in LoadBitmapFile: the file is not a bitmap file\n");
		return NULL;
	}

	fread(bitmapInfoHeader, sizeof(BITMAPINFOHEADER), 1, filePtr);
	fseek(filePtr, bitmapFileHeader.bfOffBits, SEEK_SET);
	bitmapImage = new unsigned char[bitmapInfoHeader->biSizeImage*4/3];

	if (!bitmapImage) {
		fprintf(stderr, "Error in LoadBitmapFile: memory error\n");
		return NULL;
	}

	for (int i = 0; i < bitmapInfoHeader->biSizeImage; i += 4)
	{
		fread(bitmapImage+i, 1, 3, filePtr);
		if (bitmapImage[i] == 255 && bitmapImage[i + 1] == 255 && bitmapImage[i + 2] == 255)
			bitmapImage[i + 3] = 0;
		else
			bitmapImage[i + 3] = 255;
	}

	for (imageIdx = 0;
		imageIdx < bitmapInfoHeader->biSizeImage; imageIdx += 4) {
		tempRGB = bitmapImage[imageIdx];
		bitmapImage[imageIdx] = bitmapImage[imageIdx + 2];
		bitmapImage[imageIdx + 2] = tempRGB;
	}

	fclose(filePtr);
	return bitmapImage;
}

void Texture::texload(const char * filename, int textureid)
{
	BITMAPINFOHEADER bitmapInfoHeader;                                 // bitmap��Ϣͷ
	unsigned char*   bitmapData;                                       // ��������

	bitmapData = LoadBitmapFile(filename, &bitmapInfoHeader);
	glBindTexture(GL_TEXTURE_2D, textureid);
	// ָ����ǰ�����ķŴ�/��С���˷�ʽ
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glTexImage2D(GL_TEXTURE_2D,
		0, 	    //mipmap���(ͨ��Ϊ����ʾ���ϲ�) 
		GL_RGB,	//����ϣ���������к졢�̡�������
		bitmapInfoHeader.biWidth, //����������������n�����б߿�+2 
		bitmapInfoHeader.biHeight, //�����߶ȣ�������n�����б߿�+2 
		0, //�߿�(0=�ޱ߿�, 1=�б߿�) 
		GL_RGB,	//bitmap���ݵĸ�ʽ
		GL_UNSIGNED_BYTE, //ÿ����ɫ���ݵ�����
		bitmapData);	//bitmap����ָ��  
}



void Texture::texload_alpha(const char * filename, int textureid)
{
	BITMAPINFOHEADER bitmapInfoHeader;                                 // bitmap��Ϣͷ
	unsigned char*   bitmapData;                                       // ��������

	bitmapData = LoadBitmapFile_whiteToAlpha(filename, &bitmapInfoHeader);
	glBindTexture(GL_TEXTURE_2D, textureid);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glTexImage2D(GL_TEXTURE_2D,	0, GL_RGBA,	bitmapInfoHeader.biWidth,bitmapInfoHeader.biHeight, 
		0, GL_RGBA,	GL_UNSIGNED_BYTE, bitmapData);	
}

int Texture::load_texture(const string & fname)
{
	filename = fname;
	this->texture_id = allocatedID[alloc_i];
	alloc_i++;
	texload(fname.c_str(), texture_id);
	return 0;
}

int Texture::load_texture_alpha(const string & fname)
{
	filename = fname;
	this->texture_id = allocatedID[alloc_i];
	alloc_i++;
	texload_alpha(fname.c_str(), texture_id);
	return 0;
}



Observer::Observer()
{
	memset(eye, 0, sizeof(eye));
	memset(center, 0, sizeof(center));
	memset(up, 0, sizeof(up));
}

Observer::Observer(double ex, double ey, double ez, double cx, double cy, double cz, double ux, double uy, double uz)
{
	eye[0] = ex;
	eye[1] = ey;
	eye[2] = ez;
	center[0] = cx;
	center[1] = cy;
	center[2] = cz;
	up[0] = ux;
	up[1] = uy;
	up[2] = uz;
	visionvec[0] = 0;
	visionvec[1] = 0;
	visionvec[2] = -8;
}

void Observer::set_look_method(int method)
{
	this->look_method = method;
}

void Observer::set_eye_position(float x, float y, float z)
{
	eye[0] = x; eye[1] = y; eye[2] = z;
}

void Observer::set_eye_delta_position(float dx, float dy, float dz)
{
	eye[0] += dx; eye[1] += dy; eye[2] += dz;
}

void Observer::set_center_position(float x, float y, float z)
{
	center[0] = x; center[1] = y; center[2] = z;
}

void Observer::set_center_delta_position(float dx, float dy, float dz)
{
	center[0] += dx; center[1] += dy; center[2] += dz;
}

void Observer::set_vision_vector(float x, float y, float z)
{
	visionvec[0] = x; visionvec[1] = y; visionvec[2] = z;
}

void Observer::set_vision_delta_vector(float dx, float dy, float dz)
{
	visionvec[0] += dx; visionvec[1] += dy; visionvec[2] += dz;
}

void Observer::track(const string & objname)
{
	look_method = BASED_ON_CENTER;
	relevant_obj = elements.findShapeByName(objname);
	if (relevant_obj == nullptr) return;
	old_center.x = center[0]; old_center.y = center[1]; old_center.z = center[2];
	old_objpos = relevant_obj->absolute_coordinate();
	action = OB_ACTION::TRACK;
}

void Observer::stare_at(const string & objname)
{
	look_method = BASED_ON_CENTER;
	relevant_obj = elements.findShapeByName(objname);
	if (relevant_obj == nullptr) return;
	action = OB_ACTION::STARE_AT;
}

void Observer::fix_to(const string & objname, float dx, float dy, float dz)
{
	look_method = BASED_ON_VISION;
	relevant_obj = elements.findShapeByName(objname);
	if (relevant_obj == nullptr) return;
	action = OB_ACTION::FIX_TO;
	relevant_pos_vec.x = dx; 
	relevant_pos_vec.y = dy;
	relevant_pos_vec.z = dz;
}

void Observer::reset_default()
{
	relevant_obj = nullptr;
	action = OB_ACTION::DEFAULT;
}

Point3d Observer::get_sight_vector()
{
	return Point3d(center[0] - eye[0], center[1] - eye[1], center[2] - eye[2]);
}

void Observer::glObserverLook()
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	if (action == OB_ACTION::DEFAULT || relevant_obj == nullptr)
	{
	defaultob:
		if (look_method == BASED_ON_CENTER)
			gluLookAt(eye[0], eye[1], eye[2], center[0], center[1], center[2], up[0], up[1], up[2]); //0,0,8,0,0,0,0,1,0
		else if (look_method == BASED_ON_VISION)
			gluLookAt(eye[0], eye[1], eye[2], eye[0] + visionvec[0], eye[1] + visionvec[1], eye[2] + visionvec[2], up[0], up[1], up[2]);

	}
	else if (action == OB_ACTION::TRACK && look_method == BASED_ON_CENTER)
	{
		//eye: (0,0,8) center:(1,2,3) obj:(-1,1,2)
		Point3d objpos = relevant_obj->absolute_coordinate();
		Point3d nowcenter(center[0], center[1], center[2]);
		Point3d noweye(eye[0], eye[1], eye[2]);
		Point3d realcenter = objpos - old_objpos + nowcenter;
		Point3d realeye = realcenter + noweye - nowcenter;

		gluLookAt(realeye.x, realeye.y, realeye.z, realcenter.x, realcenter.y, realcenter.z, up[0], up[1], up[2]);
	}
	else if (action == OB_ACTION::STARE_AT && look_method == BASED_ON_CENTER)
	{
		Point3d objpos = relevant_obj->absolute_coordinate();
		gluLookAt(eye[0], eye[1], eye[2], objpos.x, objpos.y, objpos.z, up[0], up[1], up[2]);
	}
	else if (action == OB_ACTION::FIX_TO && look_method == BASED_ON_VISION)
	{
		Point3d objpos = relevant_obj->absolute_coordinate();
		gluLookAt(objpos.x + relevant_pos_vec.x, objpos.y + relevant_pos_vec.y, objpos.z + relevant_pos_vec.z,
			objpos.x + relevant_pos_vec.x + visionvec[0], 
			objpos.y + relevant_pos_vec.y + visionvec[1],
			objpos.z + relevant_pos_vec.z + visionvec[2], up[0], up[1], up[2]);
	}
	else goto defaultob;
}




Condition::Condition(const string & condstr)
{
	this->cond = condstr;
}

bool Condition::operator()(Shape * p)
{
	//if (p == nullptr) p = context.current_condition_default;
	if (subconds.size() == 0)
	{
		string subcond;
		for (int i = 0; i < cond.size(); ++i)
		{
			char ch = cond.at(i);
			if (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r') continue;
			if (ch == '&')
			{
				if (subcond.size() > 0)
				{
					subconds.push_back(subcond);
					subcond.clear();
				}
				continue;
			}
			subcond.append(1, ch);
		}
		if (subcond.size()) subconds.push_back(subcond);
	}

	bool res = 1;
	for (string thiscond : subconds)
	{
		if (thiscond == "true")
		{
			res &= 1; continue;
		}
		if (thiscond == "false")
		{
			res &= 0; continue;
		}

		int condpos;
		int cmp = -1;
		if ((condpos = thiscond.find(">=")) != string::npos) cmp = 1;
		else if ((condpos = thiscond.find("<=")) != string::npos) cmp = 2;
		else if ((condpos = thiscond.find("==")) != string::npos) cmp = 3;
		else if ((condpos = thiscond.find("!=")) != string::npos) cmp = 4;
		else if ((condpos = thiscond.find("<")) != string::npos) cmp = 5;
		else if ((condpos = thiscond.find(">")) != string::npos) cmp = 6;
		else if ((condpos = thiscond.find("=1b")) != string::npos) cmp = 7;
		else if ((condpos = thiscond.find("=0b")) != string::npos) cmp = 8;

		if (cmp != -1)
		{
			int others = 0;
			Shape *othersp = nullptr;
			if (thiscond[0] == '$')
			{
				others = 1;
				int pos1 = thiscond.find('$') + 1;
				int pos2 = thiscond.find('.') - 1;
				string itsname = thiscond.substr(pos1, pos2 - pos1 + 1);
				others = pos2 + 2;
				othersp = elements.findShapeByName(itsname);
			}
			Shape *rp = (others == 0 ? p : othersp);
			string cmpl = (others == 0 ? thiscond.substr(0, condpos) : thiscond.substr(others, condpos - others));
			int d;
			if (cmp == 5 || cmp == 6) d = 1;
			else if (cmp == 7 || cmp == 8) d = 3;
			else d = 2;
			string cmpr = thiscond.substr(condpos + d);
			float fval;
			int ival;

			if (cmpr[0] == '$')
			{
				int pos1 = cmpr.find('$') + 1;
				int pos2 = cmpr.find('.') - 1;
				string itsname = cmpr.substr(pos1, pos2 - pos1 + 1);
				Shape *ropr = elements.findShapeByName(itsname);
				string which = cmpr.substr(pos2 + 2);
				if (which == "state") 
					fval = ropr->state;
				else 
				{
					Point3d roprpos = ropr->absolute_coordinate();
					if (which == "pos.x") fval = roprpos.x;
					if (which == "pos.y") fval = roprpos.y;
					if (which == "pos.z") fval = roprpos.z;
				}

				ival = (int)fval;
			}
			else
			{
				fval = stof(cmpr);
				if (cmpr.find(".") == string::npos) ival = stoi(cmpr);
			}
			if (cmpl == "state")
			{
				if (cmp == 1) res &= (rp->state >= ival);
				if (cmp == 2) res &= (rp->state <= ival);
				if (cmp == 3) res &= (rp->state == ival);
				if (cmp == 4) res &= (rp->state != ival);
				if (cmp == 5) res &= (rp->state < ival);
				if (cmp == 6) res &= (rp->state > ival);
				if (cmp == 7) res &= !!(rp->state & (1 << ival));
				if (cmp == 8) res &= !(rp->state & (1 << ival));
			}
			Point3d objpos = rp->absolute_coordinate();
			if (cmpl == "pos.x" || cmpl == "position.x") 
			{
				if (cmp == 1) res &= (objpos.x >= fval);
				if (cmp == 2) res &= (objpos.x <= fval);
				if (cmp == 3) res &= (objpos.x == fval);
				if (cmp == 4) res &= (objpos.x != fval);
				if (cmp == 5) res &= (objpos.x < fval);
				if (cmp == 6) res &= (objpos.x > fval);
			};
			if (cmpl == "pos.y" || cmpl == "position.y")
			{
				if (cmp == 1) res &= (objpos.y >= fval);
				if (cmp == 2) res &= (objpos.y <= fval);
				if (cmp == 3) res &= (objpos.y == fval);
				if (cmp == 4) res &= (objpos.y != fval);
				if (cmp == 5) res &= (objpos.y < fval);
				if (cmp == 6) res &= (objpos.y > fval);
			};
			if (cmpl == "pos.z" || cmpl == "position.z")
			{
				if (cmp == 1) res &= (objpos.z >= fval);
				if (cmp == 2) res &= (objpos.z <= fval);
				if (cmp == 3) res &= (objpos.z == fval);
				if (cmp == 4) res &= (objpos.z != fval);
				if (cmp == 5) res &= (objpos.z < fval);
				if (cmp == 6) res &= (objpos.z > fval);
			};
		}
		else
		{
			string func, objx, val; 
			//reach:object,val
			//01234567890123456
			//a5; b12; c16
			//0,5; 6,6; 13,3;
			int a = thiscond.find(':'), b = thiscond.find(','), c = -1;
			if (c == -1) c = thiscond.size();
			func = thiscond.substr(0, a);
			objx = thiscond.substr(a + 1, b - a - 1);
			val = thiscond.substr(b + 1, c - b - 1);
			if (func == "reach")
			{
				Shape *target = elements.findShapeByName(objx);
				float fdist = stof(val);
				auto sq = [](float x) -> float {return x * x; };
				
				Point3d A = p->absolute_coordinate(), B = target->absolute_coordinate();
				if (sq(A.x - B.x) + sq(A.y - B.y) + sq(A.z - B.z) <= sq(fdist))
				{
					res &= true;
				}
				else res &= false;
				//if(p->name == "@coin") cout << sq(A.x - B.x) + sq(A.y - B.y) + sq(A.z - B.z) << "--" << sq(fdist) << endl;
			}
			if (func == "collide")
			{
				Shape *target = elements.findShapeByName(objx);
				float fdist = (p->collide_radius() + target->collide_radius()) * 0.9;
				auto sq = [](float x) -> float {return x * x; };

				Point3d A = p->absolute_coordinate(), B = target->absolute_coordinate();
				if (sq(A.x - B.x) + sq(A.y - B.y) + sq(A.z - B.z) <= sq(fdist))
				{
					res &= true;
				}
				else res &= false;
			}
		}
	}

	return res;
}


RegisteredActs acts;


vector<string>& KeyMapping::forkey(int key)
{
	return this->instofkey[key];
}

KeyMapping keymap;
