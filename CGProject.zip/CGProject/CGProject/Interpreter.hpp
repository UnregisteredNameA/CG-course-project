#pragma once
#include "elements.h"
#include <iostream>
#include <vector>
#include <functional>
#include <string>
#include <iomanip>
#include "gl_funcs.h"
#include <sstream>
#include <algorithm>
#include <fstream>
#include <direct.h>
#include <io.h>

using namespace std;

extern RegisteredElements elements;
extern bool take_screenshot;


class MaterialCreator {

public:
	vector<string> cmds;
	void createMaterial()
	{
		Material *m = new Material();
		m->name = cmds[1];
		unsigned int i = 2;
		while (i < cmds.size())
		{
			if (cmds[i] == "ambient")
			{
				m->ambient = { stof(cmds[i + 1]), stof(cmds[i + 2]), stof(cmds[i + 3]), stof(cmds[i + 4]) };
				i = i + 5;
			}
			else if (cmds[i] == "specular")
			{
				m->specular = { stof(cmds[i + 1]), stof(cmds[i + 2]), stof(cmds[i + 3]), stof(cmds[i + 4]) };
				i = i + 5;
			}
			else if (cmds[i] == "diffuse")
			{
				m->diffuse = { stof(cmds[i + 1]), stof(cmds[i + 2]), stof(cmds[i + 3]), stof(cmds[i + 4]) };
				i = i + 5;
			}
			else if (cmds[i] == "emission")
			{
				m->emission = { stof(cmds[i + 1]), stof(cmds[i + 2]), stof(cmds[i + 3]), stof(cmds[i + 4]) };
				i = i + 5;
			}
			else if (cmds[i] == "shininess")
			{
				m->shininess_valid = 1;
				m->shininess = stof(cmds[i + 1]);
				i = i + 2;
			}
		}
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		lck.lock();
		elements.add_material(m);
	}

};

class TextureCreator {
public:
	vector<string> cmds;
	void createTexture(int nosendtoq = 0) 
	{
		if (nosendtoq)
		{
			Texture *nt = new Texture;
			nt->name = cmds[1];
			if (cmds[0] == "texture")
				nt->load_texture(cmds[2]);
			else if(cmds[0] == "textureA")
				nt->load_texture_alpha(cmds[2]);
			elements.add_texture(nt);
		}
		else
		{
			vector<string> inst;
			inst.push_back("load texture");
			inst.push_back(cmds[0]);
			inst.push_back(cmds[1]);
			inst.push_back(cmds[2]);
			unique_lock<mutex> lck2(drawingThreadMessageQueue_mutex, defer_lock);
			lck2.lock();
			drawingThreadMessageQueue.push(inst);
		}
	}
	void createTextureHere()
	{
		createTexture(1);
	}
};

class ShapeManager {
public:
	vector<string> cmds;

	void edit_object(Shape *obj, int startat)
	{
		int k = startat;
		while (k < cmds.size())
		{
			ShapeEditor editor;
			if (cmds[k] == "if")
			{
				++k;
				while (cmds[++k].find(')') == string::npos)
					editor.condition_str.append(cmds[k] + ' ');
			}
			if (editor.condition_str.size()) ++k;
			editor.cmd = cmds[k];
			int expect = ShapeEditor::expected_argnum(cmds[k]);
			if (expect > 0)
			{
				editor.cmdi = cmds[k + 1];
				for (int i = k + 1; i <= k + expect; ++i)
				{
					if (valid_float_number(cmds[i]))
						editor.args.push_back(stof(cmds[i]));
				}
			}

			editor(obj);
			k = k + 1 + expect;
		}
	}
	
	void interpret() 
	{
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		lck.lock();
		if (cmds[0] == "obj++" || cmds[0] == "obj")
		{
			Shape *newp = nullptr;
			int k;
			if (cmds[2] == "cube")
			{
				newp = new Cube;
				newp->set_attribute({stof(cmds[3])});
				k = 4;
			}
			else if (cmds[2] == "cuboid")
			{
				newp = new Cuboid;
				newp->set_attribute({ stof(cmds[3]), stof(cmds[4]), stof(cmds[5])});
				k = 6;
			}
			else if (cmds[2] == "sphere")
			{
				newp = new Sphere;
				newp->set_attribute({ stof(cmds[3]) });
				k = 4;
			}
			else if (cmds[2] == "cylinder")
			{
				newp = new Cylinder;
				newp->set_attribute({ stof(cmds[3]), stof(cmds[4]), stof(cmds[5]) });
				k = 6;
			}
			else if (cmds[2] == "cone")
			{
				newp = new Cone;
				newp->set_attribute({ stof(cmds[3]), stof(cmds[4]) });
				k = 5;
			}
			else if (cmds[2] == "null")
			{
				newp = new NullObject;
				k = 3;
			}
			else if (cmds[2] == "prism")
			{
				newp = new Prism;
				newp->set_attribute({ stof(cmds[3]), stof(cmds[4]), stof(cmds[5]), stof(cmds[6]) });
				k = 7;
			}
			else if (cmds[2] == "pyramid")
			{
				newp = new Pyramid;
				newp->set_attribute({ stof(cmds[3]), stof(cmds[4]), stof(cmds[5]) });
				k = 6;
			}
			else if (cmds[2] == "objfile")
			{
				ObjFile *pobj = new ObjFile;
				pobj->load_file(cmds[3]);
				newp = pobj;
				k = 4;
			}
			if (newp == nullptr)
			{
				cout << "Invalid shape!" << endl;
				return;
			}
			newp->name = cmds[1];
			edit_object(newp, k);
			if (cmds[0].size() == 3) newp->hide = 1;
			elements.add_shape(newp);
		}
		else if (cmds[0] == "obj--")
		{
			elements.remove_shape(cmds[1]);
		}
		else if (cmds[0] == "obj-")
		{
			(elements.findShapeByName(cmds[1]))->hide = 1;
		}
		else if (cmds[0] == "obj+")
		{
			(elements.findShapeByName(cmds[1]))->hide = 0;
		}
		else if (cmds[0] == "obj*")
		{
			if (cmds[1].at(0) != '@')
			{
				Shape *p = elements.findShapeByName(cmds[1]);
				int k = 2;
				edit_object(p, k);
			}
			else
			{
				vector<Shape*> vec;
				elements.multi_findShapeByName(cmds[1], vec);
				for (Shape *p : vec)
				{
					edit_object(p, 2);
				}
			}
		}
	}
};

class LightManager {
public:
	vector<string> cmds;
	void interpret()
	{
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		lck.lock();
		if (cmds[0] == "light++" || cmds[0] == "light")
		{
			Light *l = new Light;
			l->id = stoi(cmds[1]);
			int k = 2;
			while (k < cmds.size())
			{
				LightEditor editor;
				editor.cmd = cmds[k];
				editor.cmdi = cmds[k + 1];
				int expect = LightEditor::expected_argnum(cmds[k]);
				for (int i = k + 1; i <= k + expect; ++i)
					if (valid_float_number(cmds[i]))
						editor.args.push_back(stof(cmds[i]));
				editor(l);
				k = k + 1 + expect;
			}
			if (cmds[0] == "light++") l->on = 1; else l->on = 0;
			elements.add_light(l);
		}
		else if (cmds[0] == "light+")
		{
			Light *lp = elements.findLightByID(stoi(cmds[1]));
			lp->on = 1;
		}
		else if (cmds[0] == "light-")
		{
			Light *lp = elements.findLightByID(stoi(cmds[1]));
			lp->on = 0;
		}
		else if (cmds[0] == "light*") 
		{
			Light *lp = elements.findLightByID(stoi(cmds[1]));
			int k = 2;
			while (k < cmds.size())
			{
				LightEditor editor;
				editor.cmd = cmds[k];
				editor.cmdi = cmds[k + 1];
				int expect = LightEditor::expected_argnum(cmds[k]);
				for (int i = k + 1; i <= k + expect; ++i)
					if (valid_float_number(cmds[i]))
						editor.args.push_back(stof(cmds[i]));
				editor(lp);
				k = k + 1 + expect;
			}
		}
	}
};

class AnimationManager {
public:

	string name, objname;
	vector<string> parastrs;
	vector<string> editcmds;  
	string starton, stopon;
	void interpret()
	{
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		lck.lock();
		int duration = (parastrs[0] == "inf" ? EVERLASTING : stoi(parastrs[0]));
		Animation *anim = new Animation(name, objname, duration, stoi(parastrs[1]), stoi(parastrs[2]));

		for (int i = 0; i < editcmds.size(); )
		{
			string comp;
			int func = -1;
			if (editcmds[i] == "if")
			{
				while (editcmds[i].find(')') == string::npos)
				{
					comp = comp + editcmds[i] + ' ';
					++i;					
					if (editcmds[i].find('(') != string::npos)
						++func;
				}
				if (func) 
				{
					comp = comp + editcmds[i] + ' ';
					++i;
					while (editcmds[i].find(')') == string::npos)
					{
						comp = comp + editcmds[i] + ' ';
						++i;
					}
				}
			}
			if (comp.size())
			{
				comp = comp + editcmds[i] + ' ';
				++i;
			}
			int nn = ShapeEditor::expected_argnum(editcmds[i]) + 1;
			while (nn--)
			{
				comp = comp + editcmds[i] + ' ';
				++i;
			}
			ShapeEditor *e = new ShapeEditor(comp);
			anim->add_object_edits(e);
		}

		if (starton.size()) anim->conditions.startOn = new Condition(starton);
		if (stopon.size()) anim->conditions.stopOn = new Condition(stopon);

		unique_lock<recursive_mutex> lck2(acts.lock, defer_lock);
		lck2.lock();
		acts.add_animation(anim);
	}

};

class EventManager {
public:	
	Event *ep;
	string name, objname, delay;
	string condition;
	void add_event()
	{
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		lck.lock();
		if (ep == nullptr) return;
		ep->name = name;
		ep->set_trigger_object(objname);
		ep->triggerOn = new Condition(condition);

		unique_lock<recursive_mutex> lck2(acts.lock, defer_lock);
		lck2.lock();
		acts.add_event(ep);
	}
	void reset(const string &event_name)
	{
		unique_lock<recursive_mutex> lck2(acts.lock, defer_lock);
		lck2.lock();
		Event* evp = acts.findEventByName(event_name);
		evp->reset();
	}

};

class ObserverManager {
	/*
	observer eye/eye+ [3 args]
	observer center/center+ [3 args]
	observer up [3 args]
	observer track objname
	observer stareat objname
	observer default
	observer fixto objname [3args]
	*/
public:
	string cmd, objname;
	vector<float> args;
	void edit_observer()
	{
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		lck.lock();
		if (cmd == "eye")
			elements.ob.set_eye_position(args[0], args[1], args[2]);
		else if (cmd == "eye+")
			elements.ob.set_eye_delta_position(args[0], args[1], args[2]);
		else if (cmd == "center")
			elements.ob.set_center_position(args[0], args[1], args[2]);
		else if (cmd == "center+")
			elements.ob.set_center_delta_position(args[0], args[1], args[2]);
		else if (cmd == "up")
		{
			elements.ob.up[0] = args[0]; elements.ob.up[1] = args[1]; elements.ob.up[2] = args[2];
		}
		else if (cmd == "default")
			elements.ob.reset_default();
		else if (cmd == "track")
			elements.ob.track(objname);
		else if (cmd == "stareat")
			elements.ob.stare_at(objname);
		else if (cmd == "fixto")
			elements.ob.fix_to(objname, args[0], args[1], args[2]);
		else if (cmd == "method")
		{
			if(objname == "vision")
				elements.ob.set_look_method(Observer::BASED_ON_VISION);
			else if (objname == "center")
				elements.ob.set_look_method(Observer::BASED_ON_CENTER);
		}
		else if (cmd == "vision")
			elements.ob.set_vision_vector(args[0], args[1], args[2]);
		else if (cmd == "vision+")
			elements.ob.set_vision_delta_vector(args[0], args[1], args[2]);
	}
};

class FocusManager {
public:
	void interpret(const string &str)
	{
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		lck.lock();
		if (str.substr(0, 6) == "focus+") elements.focus_next();
		else if (str.substr(0, 6) == "focus-") elements.focus_prev();
		else {
			stringstream ss(str);
			string sx; 
			ss >> sx >> sx; 
			sx = sx.substr(0, sx.find(';'));
			elements.set_focus(sx);
		}
	}
};

class SceneSaver {
public:
	void save()
	{
		vector<Shape*> allshapes;
		unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
		lck.lock();
		for (auto it = elements.shapes.begin(); it != elements.shapes.end(); ++it)
			allshapes.push_back(*it);
		auto cmp = [](Shape *a, Shape *b) -> bool { return a->get_int_id() < b->get_int_id(); };
		sort(allshapes.begin(), allshapes.end(), cmp);

		string all;
		for (auto it = elements.textures.begin(); it != elements.textures.end(); ++it)
			all += (*it)->to_string() + '\n';
		for (auto it = elements.materials.begin(); it != elements.materials.end(); ++it)
			all += (*it)->to_string() + '\n';
		for (auto it = elements.lights.begin(); it != elements.lights.end(); ++it)
			all += (*it)->to_string() + '\n';
		for (auto it = allshapes.begin(); it != allshapes.end(); ++it)
		{
			string eles;
			(*it)->to_string(eles);
			all += eles;
		}

		all += GlobalSettings::to_string();

		lck.unlock();

		if (0 != _access("scenes", 0))
		{
			_mkdir("scenes");   
		}

		time_t xx;
		time(&xx);
		tm *p = localtime(&xx);
		string hh = to_string(p->tm_hour); if (hh.size() == 1) hh = "0" + hh;
		string mm = to_string(p->tm_min); if (mm.size() == 1) mm = "0" + mm;
		string ss = to_string(p->tm_sec); if (ss.size() == 1) ss = "0" + ss;

		string fn = string("scenes/scene") +
			to_string(p->tm_year + 1900) + "-" + to_string(p->tm_mon + 1) + "-" + to_string(p->tm_mday) + "-" +
			hh + mm + ss + ".txt";

		ofstream fout(fn);

		fout << all << endl;
		fout.close();
		cout << "Scene saved!" << endl;
	}
};

class Partitioner {
public:
	vector<string> subs;
	void clear()
	{
		subs.clear();
	}
	void partition(const string &statement)
	{
		int pos1, pos2;
		pos1 = statement.find('{') + 1;
		while (1)
		{
			pos2 = statement.find('}', pos1);
			if (statement.find('}', pos2+1) == string::npos) 
				pos2 = statement.find(';', pos1);
			if (pos2 == string::npos) break;
			while (statement[pos1] == ' ' || statement[pos1] == '\t' || statement[pos1] == '\n') pos1++;
			subs.push_back(statement.substr(pos1, pos2 - pos1 + 1));
			pos1 = pos2 + 1;
		}
	}
};



static map<string, string> predefine;

class Interpreter
{
private:
	MaterialCreator materialm;
	TextureCreator texturem;
	ShapeManager shapem;
	LightManager lightm;
	AnimationManager animm;
	EventManager eventm;
	ObserverManager obm;
	FocusManager focusm;
	SceneSaver scenesvm;

	int in_main_thread = 0;


public:

	void input_from_file(ifstream &fin)
	{
		in_main_thread = 1;
		fin >> noskipws;
		char buf[2000];
		while (1)
		{
 			string str;
			char endwith = ';';
			int beg = 1, def = 0;
 			while (1)
			{
				char ch;
				fin >> ch;
				//cout << ch;

				if (str.size() == 0 && ch == '#') def = 1;
				if (!fin.good()) return;

				if (!def && ch == '[')
				{
					string xx;
					while (fin >> ch && ch != ']') xx += ch;
					str.append(predefine[xx]);
					continue;
				}

				if (str.size() == 0 && (ch == ' ' || ch == '\n')) continue;
				if (ch == '\n' || ch == '\t') ch = ' ';
				if (ch == '(' || ch == ')' || ch == ';') str.append(1, ' ');
				str.append(1, ch);
				if (ch == '(' || ch == ')' || ch == ';') str.append(1, ' ');
				if (ch == '{') endwith = '}';
				if (ch == endwith) break;
				if (!fin.good())break;
			}
			if (str.substr(0, 7) == "#define")
			{
				int pos1, pos2;
				string from, to;
				pos1 = str.find('[') + 1;
				pos2 = str.find(']') - 1;
				from = str.substr(pos1, pos2 - pos1 + 1);
				pos1 = str.find('[', pos2) + 1;
				pos2 = str.find(']', pos1) - 1;
				to = str.substr(pos1, pos2 - pos1 + 1);
				predefine[from] = to;
			}
			if(!def) interpret(str);
		}
	}
	void input()
	{
		cin >> noskipws;
		char buf[2000];		
		while (1)
		{
			string str;
			char endwith = ';';
			while (1)
			{
				char ch;
				cin >> ch;
				if (str.size() == 0 && (ch == ' ' || ch == '\n')) continue;
				if (ch == '\n'|| ch == '\t') ch = ' ';
				if (ch == '(' || ch == ')' || ch == ';') str.append(1, ' ');
				str.append(1, ch);
				if (ch == '(' || ch == ')' || ch == ';') str.append(1, ' ');
				if (ch == '{') endwith = '}';
				if (ch == endwith) break;
			}
			interpret(str);
		}
	}
	void interpret(string statement)
	{
		stringstream sin(statement);
		sin >> skipws;
		
		{
			unique_lock<mutex> noinlock(drawingThreadMessageQueue_mutex, defer_lock);
			noinlock.lock();
			while (!drawingThreadMessageQueue.empty())
			{
				noinlock.unlock();
				Sleep(100);
				noinlock.lock();
				continue;
			}
			noinlock.unlock();
			string str;
			sin >> str;
			if (str == "if")
			{
				int pos1 = statement.find('(') + 1;
				int pos2 = statement.find(')') - 1;
				Condition cond(statement.substr(pos1, pos2 - pos1 + 1));
				if (!cond(nullptr))
					return;
				while (str != ")") sin >> str;
				sin >> str;
			}
			if (str.substr(0, 3) == "obj")
			{
				shapem.cmds.clear();
				shapem.cmds.push_back(str);
				string cmdx;
				while ((sin >> cmdx) && cmdx.find(';') == string::npos) shapem.cmds.push_back(cmdx);
				cmdx = cmdx.substr(0, cmdx.find(';'));
				if (cmdx.size()) shapem.cmds.push_back(cmdx);
				shapem.interpret();
			}
			if (str.substr(0, 5) == "light")
			{
				lightm.cmds.clear();
				lightm.cmds.push_back(str);
				string cmdx;
				while ((sin >> cmdx) && cmdx.find(';') == string::npos) lightm.cmds.push_back(cmdx);
				cmdx = cmdx.substr(0, cmdx.find(';'));
				if (cmdx.size()) lightm.cmds.push_back(cmdx);
				lightm.interpret();
			}
			if (str == "material")
			{
				materialm.cmds.clear();
				materialm.cmds.push_back(str);
				string cmdx;
				while ((sin >> cmdx) && cmdx.find(';') == string::npos) materialm.cmds.push_back(cmdx);
				cmdx = cmdx.substr(0, cmdx.find(';'));
				if (cmdx.size()) materialm.cmds.push_back(cmdx);
				materialm.createMaterial();
			}
			if (str.substr(0, 7) == "texture")
			{
				texturem.cmds.clear();
				texturem.cmds.push_back(str);
				string cmdx;
				while ((sin >> cmdx) && cmdx.find(';') == string::npos) texturem.cmds.push_back(cmdx);
				cmdx = cmdx.substr(0, cmdx.find(';'));
				if (cmdx.size()) texturem.cmds.push_back(cmdx);
				if (!in_main_thread)
					texturem.createTexture();
				else
					texturem.createTextureHere();
			}
			if (str == "animation")
			{
				/*
					animation name for objname
					parameter(duration triginterval delay) 
					starton(condition1) 
					stopon(condition2) 	
					playwhile(condition3)	
					pausewhile(condition4)	
					{
						[obj edits]
					}
				*/
				animm.editcmds.clear();
				animm.parastrs.clear();
				string s;
				sin >> s;
				animm.name = s;
				sin >> s;
				if (s != "for") return;
				sin >> s;
				animm.objname = s;
				int pos, pose;
				pos = statement.find("parameter");
				if (pos != string::npos)
				{
					pos = statement.find('(', pos);
					pose = statement.find(')', pos);
					pos++; pose--;
					string tmp = statement.substr(pos, pose - pos + 1);
					stringstream ss(tmp);
					string x;
					ss >> x; animm.parastrs.push_back(x);
					ss >> x; animm.parastrs.push_back(x);
					ss >> x; animm.parastrs.push_back(x);
				}
				int pos1, pos2, posf = pose+1;
				auto cutstr = [statement](int p, int &posf) -> string {
					if (p != string::npos)
					{
						int pos1 = statement.find('(', p);
						int pos2 = statement.find(')', p);
						if (pos2 > posf) posf = pos2;
						pos1++; pos2--;
						return statement.substr(pos1, pos2 - pos1 + 1);
					}
					else return string();
				};
				pos = statement.find("starton");
				animm.starton = cutstr(pos, posf);

				pos = statement.find("stopon");
				animm.stopon = cutstr(pos, posf);

				pos1 = statement.find('{', posf);
				pos2 = statement.find('}', pos1);
				pos1++; pos2--;
				stringstream ess(statement.substr(pos1, pos2 - pos1 + 1));
				//animm.editcmds = 
				string tmp2;
				while ((ess >> tmp2) && tmp2.size() && ess.good()) animm.editcmds.push_back(tmp2);
				animm.interpret();
			}
			if (str == "event")
			{
				/*
				event name for objname 
				parameters(times interval delay)
				on(condition)
				{
					[statements]
				}

				event name reset;
				*/
				eventm.ep = new Event;
				string s;
				sin >> s; 
				eventm.name = s;
				sin >> s; 
				if (s == "reset" || s.substr(0,6) == "reset;")
				{
					eventm.reset(eventm.name);
					return;
				}
				if (s != "for") return;
				sin >> s; eventm.objname = s;
				int pos0, pos1, pos2;
				pos0 = statement.find("on");
				if (pos0 == string::npos) return;
				pos1 = statement.find('(', pos0);
				pos2 = statement.find(')', pos1);
				pos1++; pos2--;
				eventm.condition = statement.substr(pos1, pos2 - pos1 + 1);

				pos0 = statement.find("parameter");
				if (pos0 != string::npos)
				{
					pos1 = statement.find('(', pos0) + 1;
					pos2 = statement.find(')', pos1) - 1;
					string argss = statement.substr(pos1, pos2 - pos1 + 1);
					stringstream args_ss(argss);
					string cnt;
					int a, b, c;
					args_ss >> cnt;
					if (cnt == "inf")
						a = EVERLASTING;
					else
						a = stoi(cnt);
					args_ss >> b >> c;
					eventm.ep->set_parameters(a, b, c);
				}
				else
					eventm.ep->set_parameters(1, 100, 0);

				Partitioner parter;
				parter.partition(statement);
				for(int k = 0; k < parter.subs.size(); ++k)
					eventm.ep->add_statements(parter.subs[k]);
				eventm.add_event();
			}
			if (str == "observer" || str == "ob")
			{
				string st2 = statement;
				st2.erase(st2.find(';'));
				stringstream ss(st2);
				string x;
				ss >> x >> x;
				obm.cmd = x;
				ss >> x;
				obm.objname = x;
				obm.args.clear();
				if (valid_float_number(x)) obm.args.push_back(stof(x));
				while ((ss >> x))
				{
					if (valid_float_number(x)) obm.args.push_back(stof(x));
					if (!ss.good()) break;
				}
				obm.edit_observer();
			}
			if (str == "keyboard" || str == "key")
			{
				//keyboard debug on/off; 
				//keyboard custom on/off;
				//keyboard for [int:key] add { [statements]+ }
				//keyboard for [int:key] clear;
				//keyboard forch [char] add { [statements]+ }
				//keyboard forch [char] clear;
				//keyboard clearall;
				stringstream ss(statement);
				string sx;
				ss >> sx >> sx;
				if (sx == "debug")
				{
					ss >> sx;
					sx = sx.substr(0, sx.find(';'));
					if (sx == "on") keymap.debug = 1; 
					if (sx == "off") keymap.debug = 0;
					return; 
				}
				if (sx == "custom")
				{
					ss >> sx;
					sx = sx.substr(0, sx.find(';'));
					if (sx == "on") keymap.custom = 1;
					if (sx == "off") keymap.custom = 0;
					return;
				}
				if (sx.substr(0, 3) == "for")
				{
					int key = -1;
					string s1;
					ss >> s1;
					if (sx == "forch") key = (int)s1[0]; 
					else if (sx == "for") key = stoi(s1);
					if (key == -1) return;
					ss >> s1;
					if (s1 == "clear") keymap.forkey(key).clear();
					if (s1 == "add") 
					{
						Partitioner parter;
						parter.partition(statement);
						for (int k = 0; k < parter.subs.size(); ++k)
							keymap.forkey(key).push_back(parter.subs[k]);
					}
				}
				if (sx == "clearall")
				{
					for (int k = 0; k < keymap.MAX_KEY; ++k)
						keymap.forkey(k).clear();
				}
			}
			if (str.substr(0, 5) == "focus")
			{
				focusm.interpret(statement);
			}
			if (str == "screenshot")
			{
				take_screenshot = 1;
			}
			if (str == "save")
			{
				scenesvm.save();
			}
			if (str == "global")
			{
				stringstream ssin(statement);
				string sz;
				ssin >> sz >> sz;
				if (sz == "far")
				{
					ssin >> sz;
					GlobalSettings::perspective_far = stof(sz);
				}
				else if (sz == "background")
				{
					ssin >> sz;
					if (sz == "color")
						ssin >> GlobalSettings::background[0] >> GlobalSettings::background[1] >>
						GlobalSettings::background[2] >> GlobalSettings::background[3];
					else if (sz == "image")
						ssin >> GlobalSettings::background_texture;
				}
				else if (sz == "cover")
				{
					ssin >> sz;
					if (sz == "image")
						ssin >> GlobalSettings::cover_texture;
				}
			}
		}
	}
	Interpreter() {};
	~Interpreter() {};
};

