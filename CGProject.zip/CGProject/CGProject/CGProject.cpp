﻿#include "pch.h"
#include <iostream>
#include <thread>
#include "elements.h"
#include "opengl_manager.h"
#include "gl_funcs.h"
#include "Interpreter.hpp"
#include "actsprocessor.h"
#include <fstream>


int main(int argc, char *argv[])
{
	OpenGLManager gl(argc, argv);
	gl.setGlutReshapeFunc(DEFAULT_FUNCTION);
	gl.setGlutIdleFunc(DEFAULT_FUNCTION);


	gl.setGlutDisplayFunc(redraw);
	gl.setGlutKeyboardFunc(keyboard);
	gl.setGlutMouseFunc(mouse);
	
	gl.otherInits();

	glutTimerFunc(10, anim_event_process, ANIMATION_PROCESS_INTERVAL);

	cout << "Load existing program?\n[input 'Y' to load a file, input 'D' to load default 'program.txt']";
	char ch;
	cin >> ch;
	if (ch == 'y' || ch == 'Y' || ch == 'd' || ch == 'D')
	{
		string fname;
		if (ch == 'y' || ch == 'Y')
		{
			cout << "Input file name:";
			cin >> fname;
		}
		else
			fname = "program/program.txt";
		ifstream fin(fname);
		Interpreter fint;
		fint.input_from_file(fin);
	}

	Interpreter interpreter;
	thread interpreter_thread(&Interpreter::input, interpreter);
	interpreter_thread.detach();

	gl.startGlutMainLoop();


	return 0;
}
;