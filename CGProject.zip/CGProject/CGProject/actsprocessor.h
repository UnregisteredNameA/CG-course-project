#pragma once
#include "elements.h"
#include "Interpreter.hpp"

extern RegisteredActs acts;
void anim_event_process(int interval);

extern KeyMapping keymap;
void keyboard(unsigned char key, int x, int y);

