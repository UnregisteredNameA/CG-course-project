#pragma once
#include <queue>
#include <mutex>
#include <utility>
using namespace std;

extern queue<vector<string>> drawingThreadMessageQueue;
extern mutex drawingThreadMessageQueue_mutex;
extern bool drawing_mutex_acquired;
extern bool take_screenshot;

void redraw();

void mouse(int button, int state, int x, int y);

void keyboard(unsigned char key, int x, int y);