#include "pch.h"
#include "gl_funcs.h"
#include <set>
#include "elements.h"
#include <list>
#include "opengl_manager.h"
#include <iostream>
#include <cstdio>
#include <string>
#include <initializer_list>
#include <mutex>
#include <queue>
#include <ctime>
#include <direct.h>

#include "Interpreter.hpp"
using namespace std;

RegisteredElements elements;

queue<vector<string>> drawingThreadMessageQueue;
mutex drawingThreadMessageQueue_mutex;
bool drawing_mutex_acquired = 0;
bool take_screenshot = 0;


Texture *t;
void dbg()
{

}

bool dbgonce_runned = 0;
void dbgonce()
{
	
	
}

void dbgdraw()
{
	//(*t)();
	float x[500];
	float y[500];
	int a = 90;
	for (int i = 0; i <= a; ++i) x[i] = 1 + 1.0*i/a;
	for (int i = 0; i <= a; ++i) y[i] = 1 - 1.0*i / a*2;
	myRevolutionSurface(90, a, x, y, 1);
}

void screenshot()
{
	FILE*    copyfile;
	FILE*    writefile;
	GLubyte* pdata;
	GLubyte  BMP_Header[54];
	int    w, h;
	int    PixelDataLength;
	w = glutGet(GLUT_WINDOW_WIDTH);
	h = glutGet(GLUT_WINDOW_HEIGHT);

	PixelDataLength = w * h * 3;

	// �����ڴ�ʹ��ļ�
	pdata = (GLubyte*)malloc(PixelDataLength);
	if (pdata == 0) 
	{
		cout << "An error occurred while taking screenshot!" << endl;
		return;
	}

	copyfile = fopen("ut/header.bmp", "rb");
	if (copyfile == 0)
	{
		cout << "Cannot find ut/header.bmp!" << endl;
		return;
	}

	time_t xx;
	time(&xx);
	tm *p = localtime(&xx);
	string hh = to_string(p->tm_hour); if (hh.size() == 1) hh = "0" + hh;
	string mm = to_string(p->tm_min); if (mm.size() == 1) mm = "0" + mm;
	string ss = to_string(p->tm_sec); if (ss.size() == 1) ss = "0" + ss;

	string fn = string("screenshots/screenshot") +
		to_string(p->tm_year+1900) + "-" + to_string(p->tm_mon+1) + "-" + to_string(p->tm_mday) + "-" +
		hh + mm + ss + ".bmp";

	writefile = fopen(fn.c_str(), "wb"); 
	if (writefile == 0)
	{
		_mkdir("screenshots");
		writefile = fopen(fn.c_str(), "wb");
		if (writefile == 0)
		{
			cout << "Failed to create screenshot file!" << endl;
			return;
		}
	}

	// ��ȡ����
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glReadPixels(0, 0, w, h,
		GL_BGR_EXT, GL_UNSIGNED_BYTE, pdata);

	// ��dummy.bmp���ļ�ͷ����Ϊ���ļ����ļ�ͷ
	fread(BMP_Header, sizeof(BMP_Header), 1, copyfile);
	fwrite(BMP_Header, sizeof(BMP_Header), 1, writefile);
	fseek(writefile, 0x0012, SEEK_SET);
	fwrite(&w, sizeof(w), 1, writefile);
	fwrite(&h, sizeof(h), 1, writefile);

	// д����������
	fseek(writefile, 0, SEEK_END);
	fwrite(pdata, PixelDataLength, 1, writefile);

	// �ͷ��ڴ�͹ر��ļ�
	fclose(copyfile);
	fclose(writefile);
	free(pdata);

	cout << "Screenshot saved!" << endl;
}

void redraw()
{
	unique_lock<recursive_mutex> lck(elements.lock, defer_lock);
	lck.lock();
	drawing_mutex_acquired = 1;

	glClearColor(GlobalSettings::background[0], GlobalSettings::background[1], GlobalSettings::background[2], GlobalSettings::background[3]);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	dbgonce();
	dbg();
	/////////////////////////////////----Texture binding has to be done in this thread-------////////////////////////

	unique_lock<mutex> lck2(drawingThreadMessageQueue_mutex, defer_lock);
	lck2.lock();

	while (!drawingThreadMessageQueue.empty())
	{
		vector<string> inst = drawingThreadMessageQueue.front();
		if (inst.at(0) == "load texture")
		{
			Texture *nt = new Texture;
			nt->name = inst.at(2);
			if (inst.at(1) == "texture")
				nt->load_texture(inst.at(3));
			else if(inst.at(1) == "textureA")
				nt->load_texture_alpha(inst.at(3));
			elements.add_texture(nt);
		}
		drawingThreadMessageQueue.pop();
	}

	lck2.unlock();

	////////////////////////////////////////------------Background------------////////////////////////////////////
	glEnable(GL_TEXTURE_2D);

	OpenGLManager::setStaticViews();
	glDisable(GL_LIGHTING);

	glLoadIdentity();

	if (GlobalSettings::background_texture.size())
	{
		Texture *ptt = elements.findTextureByName(GlobalSettings::background_texture);
		glBindTexture(GL_TEXTURE_2D, ptt->texture_id);
		glColor4f(1, 1, 1, 1);

		glBegin(GL_QUADS);
		{
			glTexCoord2f(0.0, 1.0);   glVertex2f(0, INITIAL_HEIGHT);  //����
			glTexCoord2f(1.0, 1.0);   glVertex2f(INITIAL_WIDTH, INITIAL_HEIGHT);  //����
			glTexCoord2f(1.0, 0.0);   glVertex2f(INITIAL_WIDTH, 0);  //����
			glTexCoord2f(0.0, 0.0);   glVertex2f(0, 0);  //����
		}
		glEnd();
		glBindTexture(GL_TEXTURE_2D, 0);
	}
	glClear(GL_DEPTH_BUFFER_BIT);


	///////////////////////////////////////////-----Objects in scene------//////////////////////////////////////////////
	OpenGLManager::setSceneViewport();
	glLoadIdentity();

	elements.ob.glObserverLook();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);

	if (GlobalSettings::light_enabled)
		glEnable(GL_LIGHTING);
	
	elements.render_lights();

	elements.render_shapes();

	///////////////////////////////////////////-----------Cover------------//////////////////////////////////////////////
	
	if (GlobalSettings::cover_texture.size())
	{
		OpenGLManager::setStaticViews();
		glLoadIdentity();
		glDisable(GL_LIGHTING);
		glDisable(GL_DEPTH_TEST);

		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glEnable(GL_ALPHA_TEST);
		glAlphaFunc(GL_GREATER, 0.9);
		Texture *ptt = elements.findTextureByName(GlobalSettings::cover_texture);
		glBindTexture(GL_TEXTURE_2D, ptt->texture_id);
		glColor4f(1, 1, 1, 1);

		glBegin(GL_QUADS);
		{
			glTexCoord2f(0.0, 1.0);   glVertex2f(0, INITIAL_HEIGHT);  //����
			glTexCoord2f(1.0, 1.0);   glVertex2f(INITIAL_WIDTH, INITIAL_HEIGHT);  //����
			glTexCoord2f(1.0, 0.0);   glVertex2f(INITIAL_WIDTH, 0);  //����
			glTexCoord2f(0.0, 0.0);   glVertex2f(0, 0);  //����
		}
		glEnd();
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_BLEND);
		glDisable(GL_ALPHA_TEST);
		glEnable(GL_DEPTH_TEST);
	}

	glutSwapBuffers();


	if (take_screenshot)
	{
		take_screenshot = 0;
		screenshot();
	}

	drawing_mutex_acquired = 0;
}

void mouse(int button, int state, int x, int y)
{
	//printf("[btn: %d, state: %d, x: %d, y: %d]\n", button, state, x, y);
}
