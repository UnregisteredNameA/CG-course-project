#include "pch.h"
#include "opengl_manager.h"
#include <cstdio>
#include "elements.h"

int OpenGLManager::width = INITIAL_WIDTH, OpenGLManager::height = INITIAL_HEIGHT;

void default_updateView(int width, int height)
{
	//OpenGLManager::setMenuViewport();
	OpenGLManager::setSceneViewport();
}

void default_reshape(int width, int height)
{
	if (height == 0)
	{
		height = 1;
	}

	OpenGLManager::height = height - EXTRA_HEIGHT;
	OpenGLManager::width = width;

	default_updateView(OpenGLManager::height, OpenGLManager::width);
}

void default_idle()
{
	glutPostRedisplay();
}

OpenGLManager::OpenGLManager(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DEPTH | GLUT_DOUBLE);
	
	glutInitWindowSize(width, height + EXTRA_HEIGHT);
	int windowHandle = glutCreateWindow("Project");
	glewExperimental = true;
	if (glewInit() != GLEW_OK) printf("error\n");
}

void OpenGLManager::setSceneViewport()
{
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	float whRatio = (GLfloat)width / (GLfloat)height;
	gluPerspective(60, whRatio, 1.0, GlobalSettings::perspective_far);
	glMatrixMode(GL_MODELVIEW);
}

void OpenGLManager::setStaticViews()
{
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, INITIAL_WIDTH, 0, INITIAL_HEIGHT, -1, 1);
	glMatrixMode(GL_MODELVIEW);
}


void OpenGLManager::setGlutDisplayFunc(void(*f)())
{
	glutDisplayFunc(f);
}

void OpenGLManager::setGlutReshapeFunc(void(*f)(int, int))
{
	if (f == DEFAULT_FUNCTION)
		glutReshapeFunc(default_reshape);
	else
		glutReshapeFunc(f);
}

void OpenGLManager::setGlutIdleFunc(void(*f)())
{
	if (f == DEFAULT_FUNCTION)
		glutIdleFunc(default_idle);
	else
		glutIdleFunc(f); 
}

void OpenGLManager::startGlutMainLoop()
{
	glutMainLoop();
}

void OpenGLManager::setGlutTimerFunc(void(*f)(int), int x)
{
	glutTimerFunc(10, f, x);
}

void OpenGLManager::setGlutKeyboardFunc(void(*f)(unsigned char key, int x, int y))
{
	glutKeyboardFunc(f);
}

void OpenGLManager::setGlutMouseFunc(void(*f)(int button, int state, int x, int y))
{
	glutMouseFunc(f);
}




OpenGLManager::~OpenGLManager()
{
	
}

void OpenGLManager::otherInits()
{
	Texture::texture_init();
	Shape::init();
}